<style>
.report-container {
    background-color: #f8f8f8;
    padding: 20px;
    margin: 20px;
    border-radius: 10px;
}

.report-container h2 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

.behavior-table {
    width: 100%;
    border-collapse: collapse;
}

.behavior-table th, .behavior-table td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

.behavior-table th {
    background-color: #f1f1f1;
    color: #444;
}

.behavior-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.behavior-table tr:hover {
    background-color: #f1f1f1;
}

/* Additional styles for better readability */
.behavior-table td {
    font-size: 16px;
    color: #555;
}

.behavior-table th {
    font-size: 18px;
}

    </style>
<?php
include('../Database/database_connection.php');

$parent_id = $_SESSION['UserID'];

$sql = "SELECT s.FirstName, s.LastName, b.Description, b.ReportDate 
        FROM behavior_reports b
        JOIN students s ON b.StudentID = s.StudentID
        JOIN parent_student ps ON s.StudentID = ps.StudentID
        WHERE ps.ParentID = ? 
        ORDER BY b.ReportDate DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$result = $stmt->get_result();
echo "<div class='report-container'>";
echo "<h2>Behavior Reports</h2>";
echo "<table class='behavior-table'>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Behavior Report</th>
            <th>Date</th>
        </tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['FirstName']}</td>
                <td>{$row['LastName']}</td>
                <td>{$row['Description']}</td>
                <td>{$row['ReportDate']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4'>No behavior reports found</td></tr>";
}
echo "</table>";

$stmt->close();
?>
