<?php
/*
session_start();
ob_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        function confirmLogout(event) {
            event.preventDefault();
            var userConfirmed = confirm("Do you want to log out?");
            if (userConfirmed) {
                window.location.href = event.target.href;
            } else {
                return false;
            }
        }
    </script>

</head>
<body>
<script>
// Inactivity logout script
document.addEventListener('DOMContentLoaded', () => {
    let logoutTimer;
    let warningTimer;
    let countdownTimer;
    let countdownElement;

    function startTimers() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);

        if (countdownElement) {
            countdownElement.style.display = 'none';
        }

        warningTimer = setTimeout(showWarning, 60000); // 1 minute of inactivity
    }

    function showWarning() {
        if (!countdownElement) {
            countdownElement = document.createElement('div');
            countdownElement.id = 'countdown';
            countdownElement.style.position = 'fixed';
            countdownElement.style.top = '10px';
            countdownElement.style.right = '10px';
            countdownElement.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            countdownElement.style.color = '#fff';
            countdownElement.style.padding = '10px';
            countdownElement.style.borderRadius = '5px';
            countdownElement.style.zIndex = '1000';
            document.body.appendChild(countdownElement);
        }

        let countdown = 10;
        countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;
        countdownElement.style.display = 'block';

        countdownTimer = setInterval(() => {
            countdown--;
            countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;

            if (countdown <= 0) {
                clearInterval(countdownTimer);
                logoutUser();
            }
        }, 1000);

        logoutTimer = setTimeout(logoutUser, 10000);
    }

    function logoutUser() {
        if (countdownElement) {
            countdownElement.style.display = 'none';
        }
        window.location.href = '../Login_Logout/logout.php';
    }

    function resetTimersOnActivity() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);
        
        if (countdownElement) {
            countdownElement.style.display = 'none';
        }

        startTimers();
    }

    ['mousemove', 'keypress', 'click'].forEach(eventType => {
        document.addEventListener(eventType, resetTimersOnActivity);
    });

    startTimers();
});
</script>

<?php
include('../session/session_check.php');
include('../Database/database_connection.php');

// Only allow parents to access this page
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'parent') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$user_id = $_SESSION['UserID'];
$sql = "SELECT Name FROM users WHERE UserID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $parent_name);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

// Retrieve parent-specific data
$result = $conn->query("SELECT COUNT(*) AS count FROM students WHERE ParentID = $user_id");
$student_count = $result->fetch_assoc()['count'];
?>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Parent Dashboard</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="?page=children"><i class="fa-solid fa-child"></i> My Children</a></li>
                    <li><a href="?page=attendance"><i class="fa-solid fa-triangle-exclamation"></i> Attendance</a></li>
                    <li><a href="?page=grades"><i class="fa-solid fa-square-poll-vertical"></i> Grades</a></li>
                    <li><a href="?page=assignments"><i class="fa-solid fa-list-check"></i> Assignments</a></li>
                    <li><a href="?page=events"><i class="fa-regular fa-calendar-days"></i> School Events</a></li>
                    <li><a href="?page=behavior"><i class="fa-regular fa-flag"></i> Behavior Reports</a></li>
                    <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <header class="header">
                <h1>Welcome <?php echo htmlspecialchars($parent_name); ?></h1>
                <div class="header-actions">
                    <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </div>
            </header>
            <section class="dashboard-content">
                <?php
                $page = isset($_GET['page']) ? $_GET['page'] : 'children';
                switch ($page) {
                    case 'children':
                        include 'my_children.php';  // Page to display parent's children and their details
                        break;
                    case 'attendance':
                        include 'parent_attendance.php';  // Attendance records of children
                        break;
                    case 'grades':
                        include 'parent_grades.php';  // Display grades of the children
                        break;
                    case 'assignments':
                        include 'parent_assignments.php';  // Assignments given to children
                        break;
                    case 'events':
                        include 'school_events.php';  // Upcoming school events
                        break;
                    case 'behavior':
                        include 'behavior_reports.php';  // Children's behavior reports
                        break;
                    default:
                        include 'my_children.php';
                }
                ?>
            </section>
        </main>
    </div>
</body>
</html>*/

session_start();
ob_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        function confirmLogout(event) {
            event.preventDefault();
            var userConfirmed = confirm("Do you want to log out?");
            if (userConfirmed) {
                window.location.href = event.target.href;
            } else {
                return false;
            }
        }
    </script>

</head>
<body>
<script>
document.addEventListener('DOMContentLoaded', () => {
    let logoutTimer;
    let warningTimer;
    let countdownTimer;
    let countdownElement;

    function startTimers() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);

        if (countdownElement) {
            countdownElement.style.display = 'none';
        }

        warningTimer = setTimeout(showWarning, 60000); 
    }

    function showWarning() {
        if (!countdownElement) {
            countdownElement = document.createElement('div');
            countdownElement.id = 'countdown';
            countdownElement.style.position = 'fixed';
            countdownElement.style.top = '10px';
            countdownElement.style.right = '10px';
            countdownElement.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            countdownElement.style.color = '#fff';
            countdownElement.style.padding = '10px';
            countdownElement.style.borderRadius = '5px';
            countdownElement.style.zIndex = '1000';
            document.body.appendChild(countdownElement);
        }

        let countdown = 10;
        countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;
        countdownElement.style.display = 'block';

        countdownTimer = setInterval(() => {
            countdown--;
            countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;

            if (countdown <= 0) {
                clearInterval(countdownTimer);
                logoutUser();
            }
        }, 1000);

        logoutTimer = setTimeout(logoutUser, 10000);
    }

    function logoutUser() {
        if (countdownElement) {
            countdownElement.style.display = 'none';
        }
        window.location.href = '../Login_Logout/logout.php';
    }

    function resetTimersOnActivity() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);
        
        if (countdownElement) {
            countdownElement.style.display = 'none';
        }

        startTimers();
    }

    ['mousemove', 'keypress', 'click'].forEach(eventType => {
        document.addEventListener(eventType, resetTimersOnActivity);
    });

    startTimers();
});
</script>

<?php
include('../session/session_check.php');
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'parent') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$user_id = $_SESSION['UserID'];

$sql = "SELECT Name FROM users WHERE UserID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $parent_name);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

$result = $conn->query("SELECT COUNT(*) AS count FROM parent_student WHERE ParentID = $user_id");
$student_count = $result->fetch_assoc()['count'];
?>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Parent Dashboard</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="?page=children"><i class="fa-solid fa-child"></i> My Children</a></li>
                    <li><a href="?page=attendance"><i class="fa-solid fa-triangle-exclamation"></i> Attendance</a></li>
                    <li><a href="?page=grades"><i class="fa-solid fa-square-poll-vertical"></i> Grades</a></li>
                    <li><a href="?page=assignments"><i class="fa-solid fa-list-check"></i> Assignments</a></li>
                    <li><a href="?page=communication">communication</a></li>
                    <li><a href="?page=events"><i class="fa-regular fa-calendar-days"></i> School Events</a></li>
                    <li><a href="?page=behavior"><i class="fa-regular fa-flag"></i> Behavior Reports</a></li>
                    <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <header class="header">
                <h1>Welcome <?php echo htmlspecialchars($parent_name); ?></h1>
                <div class="header-actions">
                    <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </div>
            </header>
            <section class="dashboard-content">
                <?php
                $page = isset($_GET['page']) ? $_GET['page'] : 'children';
                switch ($page) {
                    case 'children':
                        include 'my_children.php';  
                        break;
                    case 'attendance':
                        include 'parent_attendance.php';  
                        break;
                    case 'grades':
                        include 'parent_grades.php';  
                        break;
                    case 'communication':
                        include 'communication.php';  
                        break;
                    case 'assignments':
                        include 'parent_assignments.php';  
                        break;
                    case 'events':
                        include 'school_events.php';  
                        break;
                    case 'behavior':
                        include 'behavior_reports.php'; 
                        break;
                    default:
                        include 'my_children.php';
                }
                ?>
            </section>
        </main>
    </div>
</body>
</html>
