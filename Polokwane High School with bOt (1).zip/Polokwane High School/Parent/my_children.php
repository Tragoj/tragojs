<?php
include('../Database/database_connection.php');

$parent_id = $_SESSION['UserID'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $child_id_number = $_POST['id_number'];
    
    $checkStudentQuery = "
        SELECT UserID as StudentID 
        FROM users 
        WHERE Role = 'student' 
        AND IDNumber = ?";
    
    $stmt = $conn->prepare($checkStudentQuery);
    $stmt->bind_param("s", $child_id_number);
    $stmt->execute();
    $student = $stmt->get_result()->fetch_assoc();
    
    if ($student) {
        $studentID = $student['StudentID'];
        
        $checkLinkQuery = "SELECT * FROM parent_student WHERE ParentID = ? AND StudentID = ?";
        $stmt = $conn->prepare($checkLinkQuery);
        $stmt->bind_param("ii", $parent_id, $studentID);
        $stmt->execute();
        $linkExists = $stmt->get_result()->fetch_assoc();
        
        if (!$linkExists) {
            $linkQuery = "INSERT INTO parent_student (ParentID, StudentID) VALUES (?, ?)";
            $stmt = $conn->prepare($linkQuery);
            $stmt->bind_param("ii", $parent_id, $studentID);
            if ($stmt->execute()) {
                $message = "Child linked successfully!";
            } else {
                $message = "Failed to link child.";
            }
        } else {
            $message = "This child is already linked to your account.";
        }
    } else {
        $message = "Student with this ID number not found.";
    }
    $stmt->close();
}

echo "<div class='child-link-container'>";
echo "<h2>Link Your Child Using ID Number</h2>";
if (isset($message)) {
    echo "<p class='message'><strong>$message</strong></p>";
}
?>
<style>
.child-link-container {
    background-color: #f9f9f9;
    padding: 20px;
    margin: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.child-link-container h2 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

.link-form {
    display: flex;
    flex-direction: column;
    margin-bottom: 30px;
}

.link-form label {
    margin-bottom: 10px;
    font-size: 16px;
    color: #555;
}

.input-field {
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

.submit-btn {
    padding: 10px 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.submit-btn:hover {
    background-color: #45a049;
}

.message {
    color: #d9534f;
    margin-bottom: 20px;
}

.children-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.children-table th, .children-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.children-table th {
    background-color: #f2f2f2;
    color: #333;
}

.children-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.children-table tr:hover {
    background-color: #f1f1f1;
}

    </style>
<form method="post" action="" class="link-form">
    <label for="id_number">Enter Child's ID Number:</label>
    <input type="text" id="id_number" name="id_number" class="input-field" required>
    <button type="submit" class="submit-btn">Link Child</button>
</form>

<?php
$sql = "SELECT s.UserID, s.Name, s.Lastname, s.Grade
        FROM users s 
        JOIN parent_student ps ON s.UserID = ps.StudentID 
        WHERE ps.ParentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$result = $stmt->get_result();

echo "<h2>My Children</h2>";
echo "<table class='children-table'>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Grade</th>
        </tr>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['Name']}</td>
                <td>{$row['Lastname']}</td>
                <td>{$row['Grade']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='3'>No children found</td></tr>";
}
echo "</table>";
echo "</div>";

$stmt->close();
$conn->close();
?>
