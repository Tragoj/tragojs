<?php
include('../Database/database_connection.php');

$parent_id = $_SESSION['UserID'];

$sql = "SELECT s.FirstName, s.LastName, a.ClassDate, a.Status 
        FROM attendance_confirmation ac
        JOIN students s ON ac.StudentID = s.StudentID
        JOIN parent_student ps ON s.StudentID = ps.StudentID
        JOIN attendance a ON ac.RegisterID = a.AttendanceID
        WHERE ps.ParentID = ? 
        ORDER BY a.ClassDate DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$result = $stmt->get_result();

echo "<style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 1.1em;
            font-family: Arial, sans-serif;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #dddddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        h2 {
            font-family: Arial, sans-serif;
            margin-top: 20px;
            color: #333;
        }
      </style>";
echo "<div class='h2'>";
echo "<h2 >Attendance Records</h2>";
echo "</div>";
echo "<table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Class Date</th>
            <th>Status</th>
        </tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['FirstName']}</td>
                <td>{$row['LastName']}</td>
                <td>{$row['ClassDate']}</td>
                <td>{$row['Status']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4'>No attendance records found</td></tr>";
}
echo "</table>";

$stmt->close();
?>
