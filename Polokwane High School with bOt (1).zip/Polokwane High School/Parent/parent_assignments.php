<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'parent') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$parent_id = $_SESSION['UserID'];

$children = [];
$sql = "SELECT UserID, FirstName, LastName FROM parents WHERE ParentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parent_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $children[] = $row;
}

$assignments_data = [];

foreach ($children as $child) {
    $student_id = $child['UserID'];

    $sql = "SELECT a.AssignmentID, a.FilePath, a.DueDate, a.StartDate, a.Status, 
                   s.FilePath AS SubmissionFilePath, s.SubmissionDate, s.GradingStatus 
            FROM assignments a 
            LEFT JOIN submissions s ON a.AssignmentID = s.AssignmentID AND s.StudentID = ? 
            WHERE a.Grade = (SELECT Grade FROM students WHERE StudentID = ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $student_id, $student_id);
    $stmt->execute();
    $assignment_result = $stmt->get_result();

    while ($assignment_row = $assignment_result->fetch_assoc()) {
        $assignments_data[] = array_merge($assignment_row, [
            'StudentFirstName' => $child['FirstName'],
            'StudentLastName' => $child['LastName']
        ]);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Child Assignments</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .assignment-container {
            width: 90%;
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="assignment-container">
        <h2>Child Assignments</h2>
        <table>
            <thead>
                <tr>
                    <th>Child Name</th>
                    <th>Assignment</th>
                    <th>Due Date</th>
                    <th>Submission Date</th>
                    <th>Grading Status</th>
                    <th>File Submission</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($assignments_data)) : ?>
                    <?php foreach ($assignments_data as $assignment) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($assignment['StudentFirstName'] . ' ' . $assignment['StudentLastName']); ?></td>
                            <td><?php echo htmlspecialchars($assignment['FilePath']); ?></td>
                            <td><?php echo htmlspecialchars($assignment['DueDate']); ?></td>
                            <td><?php echo $assignment['SubmissionDate'] ? htmlspecialchars($assignment['SubmissionDate']) : 'Not submitted'; ?></td>
                            <td><?php echo htmlspecialchars($assignment['GradingStatus'] ?? 'Not graded'); ?></td>
                            <td><?php echo $assignment['SubmissionFilePath'] ? '<a href="' . htmlspecialchars($assignment['SubmissionFilePath']) . '">View Submission</a>' : 'No submission'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6" style="text-align: center;">No assignments found for your children.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
