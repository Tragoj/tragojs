<?php
include('../Database/database_connection.php');

$parent_id = $_SESSION['UserID'];

$sqlChildren = "SELECT u.UserID as StudentID, u.Name, u.Lastname, u.Grade
                FROM users u
                JOIN parent_student ps ON u.UserID = ps.StudentID
                WHERE ps.ParentID = ?";
$stmtChildren = $conn->prepare($sqlChildren);
$stmtChildren->bind_param("i", $parent_id);
$stmtChildren->execute();
$children = $stmtChildren->get_result();

echo "<div class='result-container'>";
echo "<h2>My Children's Results</h2>";

if ($children->num_rows > 0) {
    while ($child = $children->fetch_assoc()) {
        $studentID = $child['StudentID'];
        $studentName = $child['Name'] . " " . $child['Lastname'];
        $studentGrade = $child['Grade'];

        $sqlResults = "SELECT r.Grade, r.Term, r.Subject, r.Mark
                       FROM results r
                       WHERE r.StudentID = ?";
        $stmtResults = $conn->prepare($sqlResults);
        $stmtResults->bind_param("i", $studentID);
        $stmtResults->execute();
        $results = $stmtResults->get_result();

        echo "<div class='child-results'>";
        echo "<h3>Results for $studentName (Grade: $studentGrade)</h3>";

        if ($results->num_rows > 0) {
            echo "<table class='results-table'>
                    <tr>
                        <th>Grade</th>
                        <th>Term</th>
                        <th>Subject</th>
                        <th>Mark</th>
                    </tr>";
            while ($row = $results->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['Grade']}</td>
                        <td>{$row['Term']}</td>
                        <td>{$row['Subject']}</td>
                        <td>{$row['Mark']}</td>
                      </tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No results found for this child.</p>";
        }
        echo "</div>";
    }
} else {
    echo "<p>No children linked to your account.</p>";
}

echo "</div>";

$stmtChildren->close();
$conn->close();
?>
<style>
.result-container {
    background-color: #f4f4f9;
    padding: 20px;
    margin: 20px;
    border-radius: 10px;
}

.result-container h2 {
    font-size: 26px;
    color: #333;
    margin-bottom: 20px;
}

.child-results {
    margin-top: 20px;
    margin-bottom: 40px;
    padding: 10px;
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

.child-results h3 {
    font-size: 20px;
    color: #444;
    margin-bottom: 15px;
}

.results-table {
    width: 100%;
    border-collapse: collapse;
}

.results-table th, .results-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

.results-table th {
    background-color: #f1f1f1;
    color: #333;
}

.results-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.results-table tr:hover {
    background-color: #f1f1f1;
}

    </style>