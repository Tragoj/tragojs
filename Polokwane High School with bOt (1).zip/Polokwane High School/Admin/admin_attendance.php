<?php 
include '../Database/database_connection.php';


if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$attendance_records = [];

$query = "
    SELECT ac.ConfirmationID, ac.RegisterID, s.FirstName, s.LastName, ac.ConfirmedStatus, ac.Latitude, ac.Longitude 
    FROM attendance_confirmation ac
    JOIN students s ON ac.StudentID = s.StudentID
";

$result = $conn->query($query);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $attendance_records[] = $row;
    }
} else {
    echo "<script>alert('Error fetching records. Please try again later.');</script>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Records</title>
    <style>

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

<h1>Attendance Records</h1>

<table>
    <tr>
        <th>Confirmation ID</th>
        <th>Register ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Attendance Status</th>
        <th>Latitude</th>
        <th>Longitude</th>
    </tr>
    <?php if (!empty($attendance_records)): ?>
        <?php foreach ($attendance_records as $record): ?>
            <tr>
                <td><?php echo htmlspecialchars($record['ConfirmationID']); ?></td>
                <td><?php echo htmlspecialchars($record['RegisterID']); ?></td>
                <td><?php echo htmlspecialchars($record['FirstName']); ?></td>
                <td><?php echo htmlspecialchars($record['LastName']); ?></td>
                <td><?php echo htmlspecialchars($record['ConfirmedStatus']); ?></td>
                <td>
                    <a href="https://www.google.com/maps?q=<?php echo htmlspecialchars($record['Latitude']); ?>,<?php echo htmlspecialchars($record['Longitude']); ?>" target="_blank">
                        <?php echo htmlspecialchars($record['Latitude']); ?>
                    </a>
                </td>
                <td>
                    <a href="https://www.google.com/maps?q=<?php echo htmlspecialchars($record['Latitude']); ?>,<?php echo htmlspecialchars($record['Longitude']); ?>" target="_blank">
                        <?php echo htmlspecialchars($record['Longitude']); ?>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="7">No attendance records found.</td>
        </tr>
    <?php endif; ?>
</table>

</body>
</html>
