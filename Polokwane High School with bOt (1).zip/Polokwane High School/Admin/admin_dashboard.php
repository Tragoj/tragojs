<?php
session_start();
ob_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        function confirmLogout(event) {
            event.preventDefault();
            var userConfirmed = confirm("Do you want to log out?");
            if (userConfirmed) {
                window.location.href = event.target.href;
            } else {
                return false;
            }
        }
    </script>
<style>

    </style>
</head>
<body>
<script>
document.addEventListener('DOMContentLoaded', () => {
    let logoutTimer;
    let warningTimer;
    let countdownTimer;
    let countdownElement;

    function startTimers() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);

        if (countdownElement) {
            countdownElement.style.display = 'none'; /
        }

        warningTimer = setTimeout(showWarning, 60000); // 1 minute of inactivity
    }

    function showWarning() {
        if (!countdownElement) {
            countdownElement = document.createElement('div');
            countdownElement.id = 'countdown';
            countdownElement.style.position = 'fixed';
            countdownElement.style.top = '10px';
            countdownElement.style.right = '10px';
            countdownElement.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            countdownElement.style.color = '#fff';
            countdownElement.style.padding = '10px';
            countdownElement.style.borderRadius = '5px';
            countdownElement.style.zIndex = '1000';
            document.body.appendChild(countdownElement);
        }

        let countdown = 10; // Start countdown from 10 seconds
        countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;
        countdownElement.style.display = 'block';

        countdownTimer = setInterval(() => {
            countdown--;
            countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;

            if (countdown <= 0) {
                clearInterval(countdownTimer);
                logoutUser();
            }
        }, 1000);

        // Force logout after 10 seconds (whether the countdown finishes or not)
        logoutTimer = setTimeout(logoutUser, 10000); // 10 seconds
    }

    function logoutUser() {
        if (countdownElement) {
            countdownElement.style.display = 'none'; 
        }
        window.location.href = '../Login_Logout/logout.php';
    }

    function resetTimersOnActivity() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);
        
        if (countdownElement) {
            countdownElement.style.display = 'none'; // Hide countdown if it's active
        }

        startTimers(); 
    }

    
    ['mousemove', 'keypress', 'click'].forEach(eventType => {
        document.addEventListener(eventType, resetTimersOnActivity);
    });

    
    startTimers();
});
</script>

<?php
include('../session/session_check.php');

include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}
$user_id = $_SESSION['UserID'];
$sql = "SELECT Name FROM users WHERE UserID = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $admin_name);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

$result = $conn->query("SELECT COUNT(*) AS count, Role FROM users GROUP BY Role");
$counts = [];
while ($row = $result->fetch_assoc()) {
    $counts[$row['Role']] = $row['count'];
}

$student_count = isset($counts['student']) ? $counts['student'] : 0;
$teacher_count = isset($counts['teacher']) ? $counts['teacher'] : 0;
$parent_count = isset($counts['parent']) ? $counts['parent'] : 0;
?>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Admin Dashboard</h2>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="?page=dashboard"><i class="fa-solid fa-users-gear"></i> Users</a></li>
                    <li><a href="?page=teacher"><i class="fa-solid fa-chalkboard-user"></i>Teachers</a></li>
                    <li><a href="?page=course"><i class="fa-solid fa-book"></i>Subjects</a></li>
                    <li><a href="?page=attendance"><i class="fa-solid fa-triangle-exclamation"></i>Attendance</a></li>
                    <li><a href="?page=schedule"><i class="fa-duotone fa-solid fa-clipboard-list"></i>Schedule</a></li>
                    <li><a href="?page=Assignments"><i class="fa-solid fa-list-check"></i>Assignments</a></li>
                    <li><a href="?page=notifications"><i class="fa-brands fa-rocketchat"></i> Communications</a></li>
                    
                    <li><a href="?page=Events"><i class="fa-solid fa-handshake"></i>Events</a></li>
                    
                    
                    <li><a href="?page=results"><i class="fa-solid fa-square-poll-vertical"></i>Results</a></li>
                    <li><a href="?page=behavior"><i class="fa-regular fa-flag"></i>Behavior Reports</a></li>
                    <li><a href="?page=registration"><i class="fas fa-key"></i> Pre-registration Tokens</a></li>
                    <li><a href="?page=manage_users"><i class="fa-solid fa-user-cog"></i> Manage Users</a></li>
                    <li><a id="logout-btnn" href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>            </nav>
        </aside>
        <main class="main-content">
            <header class="header">
                <h1>Welcome  <?php echo htmlspecialchars($admin_name); ?></h1>
                <div class="header-actions">
                <li id="logout-btnn"><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>

                  
                </div>
            </header>
            <section class="dashboard-content">
                <?php
                $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
                switch ($page) {
          
                    case 'timetable':
                        include 'timetable.php';
                        break;
                    case 'teacher':
                        include 'teachers_management.php';
                        break;
                        
                    case 'Events':
                        include 'Events.php';
                        break;
                        
                    case 'behavior':
                        include 'behavior.php';
                        break;
                    case 'course':
                        include 'course.php';
                        break;
                    case 'Assignments':
                        include 'manage_assignments.php';
                        break;
                    case 'schedule':
                        include 'schedule_admin.php';
                        break;
                    case 'attendance':
                            include 'admin_attendance.php';
                            break;
                    case 'asignments':
                            include 'assignments.php';
                            break; 
                    case 'results':
                        include 'results.php';
                        break;
                    case 'registration':
                        include 'pre_registration.php';
                        break;
                    case 'notifications':
                        include 'notifications.php';
                        break;
                    case 'manage_users':
                        include 'manage_users.php';
                        break;
                    default:
                        include 'dashboard.php';
                }
                ?>
            </section>
        </main>
    </div>
</body>
</html>
