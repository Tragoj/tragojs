-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2024 at 12:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `AssignmentID` int(11) NOT NULL,
  `StartDate` date NOT NULL,
  `DueDate` date NOT NULL,
  `FilePath` varchar(255) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Grade` int(11) DEFAULT NULL,
  `StreamID` int(11) DEFAULT NULL,
  `SubjectStreamID` int(11) DEFAULT NULL,
  `SubjectID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`AssignmentID`, `StartDate`, `DueDate`, `FilePath`, `status`, `created_at`, `Grade`, `StreamID`, `SubjectStreamID`, `SubjectID`) VALUES
(13, '2024-10-17', '2024-10-18', 'C:\\xampp\\htdocs\\High\\Admin/uploads/Quarterly Report.pdf', 'active', '2024-10-17 07:47:24', 10, 40, 28, 27),
(14, '2024-10-17', '2024-10-18', 'C:\\xampp\\htdocs\\High\\Admin/uploads/Quarterly Report.pdf', 'active', '2024-10-17 13:51:11', 8, NULL, NULL, 2),
(15, '2024-10-18', '2024-10-21', 'C:\\xampp\\htdocs\\High\\Admin/uploads/Project Proposal.pdf', 'active', '2024-10-18 07:40:36', 10, 40, 30, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `AttendanceID` int(11) NOT NULL,
  `TeacherID` int(11) DEFAULT NULL,
  `ClassDate` datetime DEFAULT NULL,
  `Status` enum('Sent','Completed') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`AttendanceID`, `TeacherID`, `ClassDate`, `Status`) VALUES
(1, 9, '2024-10-08 08:54:00', 'Sent'),
(2, 9, '2024-10-08 09:18:00', 'Sent'),
(3, 9, '2024-10-08 09:41:00', 'Sent'),
(4, 9, '2024-10-08 09:41:00', 'Sent'),
(5, 9, '2024-10-08 09:41:00', 'Sent'),
(6, 9, '2024-10-09 09:41:00', 'Sent'),
(7, 9, '2024-10-08 11:23:00', 'Sent'),
(8, 9, '2024-10-08 11:41:00', 'Sent'),
(9, 9, '2024-10-08 12:22:00', 'Sent'),
(10, 9, '2024-10-04 12:36:00', 'Sent'),
(11, 9, '2024-10-04 12:36:00', 'Sent'),
(12, 9, '2024-10-08 12:37:00', 'Sent'),
(13, NULL, '2024-10-08 12:41:00', 'Sent'),
(14, NULL, '2024-10-08 12:41:00', 'Sent'),
(15, NULL, '2024-10-12 17:30:00', 'Sent');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_confirmation`
--

CREATE TABLE `attendance_confirmation` (
  `ConfirmationID` int(11) NOT NULL,
  `RegisterID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `ConfirmedStatus` enum('Confirmed Present','Confirmed Absent') NOT NULL,
  `Latitude` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_confirmation`
--

INSERT INTO `attendance_confirmation` (`ConfirmationID`, `RegisterID`, `StudentID`, `ConfirmedStatus`, `Latitude`, `Longitude`) VALUES
(2, 6, 11, '', -33.9271, 18.42),
(3, 8, 11, '', -33.9271, 18.42),
(4, 9, 11, '', -33.9271, 18.42),
(5, 12, 11, '', -33.9271, 18.42),
(6, 13, 5, '', -33.9271, 18.42);

-- --------------------------------------------------------

--
-- Table structure for table `behavior_reports`
--

CREATE TABLE `behavior_reports` (
  `ReportID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `ReportDate` date DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `ReportedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `behavior_reports`
--

INSERT INTO `behavior_reports` (`ReportID`, `StudentID`, `ReportDate`, `Description`, `ReportedBy`) VALUES
(8, 17, '2024-10-16', 'didnt come to school!!!!!!!', 18);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `MessageID` int(11) NOT NULL,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `Message` text DEFAULT NULL,
  `SentAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`MessageID`, `SenderID`, `ReceiverID`, `Message`, `SentAt`) VALUES
(7, 17, 0, 'hi', '2024-10-14 13:28:27'),
(8, 17, 14, 'hi', '2024-10-14 13:28:43'),
(9, 16, 18, 'afternoon', '2024-10-14 13:36:28'),
(10, 18, 16, 'hi', '2024-10-14 13:37:32'),
(11, 16, 0, 'Morning', '2024-10-18 09:13:12'),
(12, 16, 0, 'Morning', '2024-10-18 09:14:34'),
(13, 16, 0, 'Morning', '2024-10-18 09:14:50'),
(14, 16, 0, 'Morning', '2024-10-18 09:15:30'),
(15, 16, 0, 'Morning', '2024-10-18 09:15:45'),
(16, 16, 15, 'hy', '2024-10-18 09:15:50'),
(17, 16, 0, 'hey', '2024-10-18 09:18:59'),
(18, 16, 0, 'hey', '2024-10-18 09:19:22');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventID` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Description` text DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`EventID`, `Title`, `Description`, `StartDate`, `EndDate`, `Location`, `CreatedBy`) VALUES
(8, 'Holidays', 'le skatla skolong', '2024-10-18', '2024-10-21', 'Polokwane High School', 18),
(9, 'Holidays', 'le skatla skolong', '2024-10-18', '2024-10-21', 'Polokwane High School', 18);

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `GradeID` int(11) NOT NULL,
  `GradeNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grade_subjects`
--

CREATE TABLE `grade_subjects` (
  `GradeID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `MessageID` int(11) NOT NULL,
  `GroupID` int(11) DEFAULT NULL,
  `SenderID` int(11) DEFAULT NULL,
  `MessageText` text DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `NotificationID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Message` varchar(255) NOT NULL,
  `NotificationType` enum('Assignment','Result','Attendance','General','Communication','Profile') NOT NULL,
  `DateSent` datetime DEFAULT current_timestamp(),
  `IsRead` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `ParentID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`ParentID`, `UserID`, `FirstName`, `LastName`) VALUES
(1, 15, 'parent', 'parent');

-- --------------------------------------------------------

--
-- Table structure for table `parent_student`
--

CREATE TABLE `parent_student` (
  `ParentID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent_student`
--

INSERT INTO `parent_student` (`ParentID`, `StudentID`) VALUES
(15, 17);

-- --------------------------------------------------------

--
-- Table structure for table `pre_registration_tokens`
--

CREATE TABLE `pre_registration_tokens` (
  `TokenID` int(11) NOT NULL,
  `Token` varchar(255) NOT NULL,
  `Role` enum('student','parent','teacher','admin') NOT NULL,
  `Grade` int(11) DEFAULT NULL,
  `Classroom` varchar(10) DEFAULT NULL,
  `UsedByUserID` int(11) DEFAULT NULL,
  `UsedOn` timestamp NULL DEFAULT NULL,
  `GeneratedOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `ExpiresOn` timestamp NULL DEFAULT NULL,
  `is_used` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pre_registration_tokens`
--

INSERT INTO `pre_registration_tokens` (`TokenID`, `Token`, `Role`, `Grade`, `Classroom`, `UsedByUserID`, `UsedOn`, `GeneratedOn`, `ExpiresOn`, `is_used`) VALUES
(15, 'b8ddf8', 'parent', NULL, NULL, 15, '2024-10-12 14:02:43', '2024-10-12 14:00:49', '2024-12-19 21:59:59', 1),
(16, 'a8d1ea', 'teacher', NULL, NULL, 16, '2024-10-12 14:06:05', '2024-10-12 14:04:24', '2024-12-19 21:59:59', 1),
(17, 'ee2e3a', 'student', 9, 'B', 17, '2024-10-12 14:10:37', '2024-10-12 14:09:35', '2024-12-19 21:59:59', 1),
(18, '869332', 'admin', NULL, NULL, 18, '2024-10-12 16:12:25', '2024-10-12 16:11:22', '2024-12-19 21:59:59', 1);

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `ResultID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `Grade` int(11) DEFAULT NULL,
  `Term` int(11) DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `Mark` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`ResultID`, `StudentID`, `Grade`, `Term`, `Subject`, `Mark`) VALUES
(14, 5, 9, 1, 'Sepedi', 0),
(18, 17, 9, 1, 'Mathematics', 76);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `day` date NOT NULL,
  `time` time NOT NULL,
  `subject` varchar(255) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `day`, `time`, `subject`, `grade`) VALUES
(9, '2024-10-13', '22:03:00', 'Geography', 'Grade 8'),
(11, '2024-10-13', '22:10:00', 'Mathematics', 'Grade 9'),
(12, '2024-10-14', '10:00:00', 'Mathematics', 'Grade 9'),
(13, '2024-10-21', '13:00:00', 'Geography', 'Grade 8');

-- --------------------------------------------------------

--
-- Table structure for table `streams`
--

CREATE TABLE `streams` (
  `StreamID` int(11) NOT NULL,
  `StreamName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `streams`
--

INSERT INTO `streams` (`StreamID`, `StreamName`) VALUES
(2, 'Science(Geography)'),
(3, 'Science(Agricultural science)'),
(4, 'Engineering'),
(40, 'CAT');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` int(11) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `Grade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentID`, `FirstName`, `LastName`, `Grade`) VALUES
(5, 'Matome', 'Ramashiya', 9),
(7, 'Thapelo', 'Manaka', 10),
(17, 'Student', 'student@gmail.com', 9),
(19, 'Kamogelo', 'Kamogelo', 10),
(20, 'grade_8', 'Grade', 8);

-- --------------------------------------------------------

--
-- Table structure for table `studentsubjects`
--

CREATE TABLE `studentsubjects` (
  `StudentID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `AttendanceID` int(11) NOT NULL,
  `RegisterID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `Status` enum('Present','Absent') NOT NULL,
  `ResponseTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_streams`
--

CREATE TABLE `student_streams` (
  `StudentID` int(11) NOT NULL,
  `StreamID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_streams`
--

INSERT INTO `student_streams` (`StudentID`, `StreamID`) VALUES
(7, 2),
(19, 40);

-- --------------------------------------------------------

--
-- Table structure for table `subjectdetails`
--

CREATE TABLE `subjectdetails` (
  `SubjectName` varchar(255) NOT NULL,
  `Instructions` text DEFAULT NULL,
  `AssignmentFile` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SubjectID` int(11) NOT NULL,
  `SubjectName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`SubjectID`, `SubjectName`) VALUES
(1, 'Mathematics'),
(2, 'Creative Arts'),
(3, 'Technology'),
(4, 'Geography'),
(5, 'History'),
(6, 'Natural Sciences'),
(7, 'English'),
(8, 'Sepedi'),
(9, 'Life Orientation');

-- --------------------------------------------------------

--
-- Table structure for table `subject_streams`
--

CREATE TABLE `subject_streams` (
  `StreamID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL,
  `SubjectName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject_streams`
--

INSERT INTO `subject_streams` (`StreamID`, `SubjectID`, `SubjectName`) VALUES
(2, 1, 'life orientation'),
(2, 2, 'mathematics'),
(2, 4, 'Geography'),
(2, 11, 'sepedi'),
(2, 12, 'english'),
(2, 13, 'physical science'),
(2, 14, 'life science'),
(3, 1, 'life orientation'),
(3, 2, 'mathematics'),
(3, 11, 'sepedi'),
(3, 12, 'english'),
(3, 13, 'physical science'),
(3, 14, 'life science'),
(3, 15, 'Agricultural science'),
(4, 1, 'life orientation'),
(4, 2, 'mathematics'),
(4, 11, 'sepedi'),
(4, 12, 'english'),
(4, 13, 'physical science'),
(4, 14, 'life science'),
(4, 16, 'civil engineering'),
(40, 24, 'Life Orientation'),
(40, 25, 'Mathematics'),
(40, 26, 'Sepedi'),
(40, 27, 'English'),
(40, 28, 'Web Tech'),
(40, 29, 'Programming'),
(40, 30, 'Information Technology');

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `SubmissionID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `FilePath` varchar(255) NOT NULL,
  `SubmissionDate` datetime NOT NULL,
  `GradingStatus` varchar(50) DEFAULT 'Not graded'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`SubmissionID`, `StudentID`, `AssignmentID`, `FilePath`, `SubmissionDate`, `GradingStatus`) VALUES
(5, 5, 1, '../Admin/uploads/Operating systems 700 Assignment.pdf', '2024-08-26 14:24:59', 'Not graded'),
(6, 5, 7, '../Admin/uploads/software engineering 402201784.pdf', '2024-10-03 20:18:55', 'Not graded'),
(7, 5, 8, '../Admin/uploads/Quarterly Report.pdf', '2024-10-07 09:44:10', 'Not graded'),
(8, 17, 7, '../Admin/uploads/Configure Access Control.pdf', '2024-10-14 15:27:43', 'Not graded');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `TeacherID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`TeacherID`, `UserID`, `FirstName`, `LastName`, `Subject`) VALUES
(1, 9, 'Karabo Piet ', 'Mogale', ''),
(2, 10, 'Tumelo Faith', 'Baloyi', ''),
(3, 16, 'Teacher', 'Teacher', '');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_assignments`
--

CREATE TABLE `teacher_assignments` (
  `AssignmentID` int(11) NOT NULL,
  `TeacherID` int(11) DEFAULT NULL,
  `SubjectID` int(11) DEFAULT NULL,
  `Grade` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_assignments`
--

INSERT INTO `teacher_assignments` (`AssignmentID`, `TeacherID`, `SubjectID`, `Grade`) VALUES
(24, 9, 1, 'Grade 9'),
(26, 10, 3, 'Grade 9'),
(27, 9, 8, 'Grade 9'),
(29, 16, 4, 'Grade 8');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `TimetableID` int(11) NOT NULL,
  `ClassID` int(11) DEFAULT NULL,
  `Day` enum('Monday','Tuesday','Wednesday','Thursday','Friday') DEFAULT NULL,
  `Period` int(11) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `TeacherID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timetables`
--

CREATE TABLE `timetables` (
  `TimetableID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL,
  `Grade` int(11) NOT NULL,
  `Schedule` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Gender` enum('Female','Male') DEFAULT NULL,
  `Class` varchar(50) DEFAULT NULL,
  `Role` enum('student','parent','teacher','admin') NOT NULL,
  `Grade` int(11) DEFAULT NULL,
  `StreamChosen` tinyint(1) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `active` tinyint(1) DEFAULT 1,
  `IDNumber` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Name`, `Lastname`, `Email`, `Address`, `Password`, `DOB`, `Gender`, `Class`, `Role`, `Grade`, `StreamChosen`, `status`, `active`, `IDNumber`) VALUES
(15, 'parent', 'parent', 'parent@gmail.com', 'tuef', '$2y$10$hMPW2b8SbwUWskRdh/Ll0u6/2PsuhBTRHLNOAgNc9osgJU6MuqzJG', '1990-05-15', 'Male', NULL, 'parent', NULL, 0, 'active', 1, '9005151234080'),
(16, 'Teacher', 'Teacher', 'teacher@gmail.com', 'seshego', '$2y$10$FMPmOZXRAUOoxOJ2047yMuqhPjtsdcZdTiHwhg3Xsd0glgJdztbnW', NULL, NULL, NULL, 'teacher', NULL, 0, 'active', 1, ''),
(17, 'Student', 'Student', 'student@gmail.com', 'student', '$2y$10$HP16XYRq0XZmyQUmV3X/oOfC/9AZhODRtek1DulyVcghnWSkML/wS', '2008-10-15', 'Male', NULL, 'student', 9, 0, 'active', 1, '0810151234080'),
(18, 'Admin', 'Admin', 'admin@gmail.com', 'seshego', '$2y$10$LHRHMh3MUgaTGQutjXL2EOXC2KcZ5NHole4FcO0VpPJRHUXnBlm9G', '2002-10-01', 'Male', NULL, 'admin', NULL, 0, 'active', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`AssignmentID`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`AttendanceID`),
  ADD KEY `TeacherID` (`TeacherID`);

--
-- Indexes for table `attendance_confirmation`
--
ALTER TABLE `attendance_confirmation`
  ADD PRIMARY KEY (`ConfirmationID`),
  ADD KEY `RegisterID` (`RegisterID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `behavior_reports`
--
ALTER TABLE `behavior_reports`
  ADD PRIMARY KEY (`ReportID`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `ReportedBy` (`ReportedBy`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`MessageID`),
  ADD KEY `SenderID` (`SenderID`),
  ADD KEY `ReceiverID` (`ReceiverID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `CreatedBy` (`CreatedBy`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`GradeID`);

--
-- Indexes for table `grade_subjects`
--
ALTER TABLE `grade_subjects`
  ADD PRIMARY KEY (`GradeID`,`SubjectID`),
  ADD KEY `SubjectID` (`SubjectID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`MessageID`),
  ADD KEY `GroupID` (`GroupID`),
  ADD KEY `SenderID` (`SenderID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`NotificationID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`ParentID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `parent_student`
--
ALTER TABLE `parent_student`
  ADD PRIMARY KEY (`ParentID`,`StudentID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `pre_registration_tokens`
--
ALTER TABLE `pre_registration_tokens`
  ADD PRIMARY KEY (`TokenID`),
  ADD UNIQUE KEY `Token` (`Token`),
  ADD KEY `UsedByUserID` (`UsedByUserID`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`ResultID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `day` (`day`,`time`,`grade`);

--
-- Indexes for table `streams`
--
ALTER TABLE `streams`
  ADD PRIMARY KEY (`StreamID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `studentsubjects`
--
ALTER TABLE `studentsubjects`
  ADD PRIMARY KEY (`StudentID`,`SubjectID`),
  ADD KEY `SubjectID` (`SubjectID`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`AttendanceID`),
  ADD KEY `RegisterID` (`RegisterID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `student_streams`
--
ALTER TABLE `student_streams`
  ADD PRIMARY KEY (`StudentID`,`StreamID`),
  ADD KEY `StreamID` (`StreamID`);

--
-- Indexes for table `subjectdetails`
--
ALTER TABLE `subjectdetails`
  ADD PRIMARY KEY (`SubjectName`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SubjectID`);

--
-- Indexes for table `subject_streams`
--
ALTER TABLE `subject_streams`
  ADD PRIMARY KEY (`StreamID`,`SubjectID`),
  ADD KEY `SubjectID` (`SubjectID`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`SubmissionID`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `AssignmentID` (`AssignmentID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`TeacherID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  ADD PRIMARY KEY (`AssignmentID`),
  ADD KEY `TeacherID` (`TeacherID`),
  ADD KEY `SubjectID` (`SubjectID`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`TimetableID`),
  ADD KEY `ClassID` (`ClassID`),
  ADD KEY `TeacherID` (`TeacherID`);

--
-- Indexes for table `timetables`
--
ALTER TABLE `timetables`
  ADD PRIMARY KEY (`TimetableID`),
  ADD KEY `SubjectID` (`SubjectID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `AssignmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `AttendanceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `attendance_confirmation`
--
ALTER TABLE `attendance_confirmation`
  MODIFY `ConfirmationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `behavior_reports`
--
ALTER TABLE `behavior_reports`
  MODIFY `ReportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `MessageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `EventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `GradeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `MessageID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `NotificationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `ParentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pre_registration_tokens`
--
ALTER TABLE `pre_registration_tokens`
  MODIFY `TokenID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `ResultID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `streams`
--
ALTER TABLE `streams`
  MODIFY `StreamID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `StudentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `AttendanceID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subject_streams`
--
ALTER TABLE `subject_streams`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `SubmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `TeacherID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  MODIFY `AssignmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `TimetableID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timetables`
--
ALTER TABLE `timetables`
  MODIFY `TimetableID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
