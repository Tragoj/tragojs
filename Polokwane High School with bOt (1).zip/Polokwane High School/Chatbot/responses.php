<?php
$responses = [
    'admin' => [
        "What is my role?" => "You are an administrator responsible for managing users.",
        "How can I manage users?" => "You can manage users through the user management dashboard.",
        "What reports can I generate?" => "You can generate various reports from the reporting section.",
        "How do I reset a password?" => "You can reset a password through the user settings.",
        "Where can I find help?" => "Help can be found in the help section of the dashboard.",
        "What are the system requirements?" => "System requirements can be found on the website.",
        "How do I add new courses?" => "New courses can be added in the course management area.",
        "How can I update user information?" => "You can update user information from the user management page.",
        "What is the fee structure?" => "The fee structure is available on the finance page.",
        "How can I contact support?" => "You can contact support via the support section."
    ],
    'student' => [
        "How do I enroll in a course?" => "You can enroll in a course from the course catalog.",
        "What is my course schedule?" => "Your course schedule can be found on your profile.",
        "How do I submit assignments?" => "Assignments can be submitted via the assignments portal.",
        "Where can I find study materials?" => "Study materials are available in the resources section.",
        "How can I contact my instructor?" => "You can contact your instructor through the messaging system.",
        "What are the exam dates?" => "Exam dates are posted in the announcements section.",
        "How do I check my grades?" => "Your grades can be checked in the grades section of your profile.",
        "What is the grading policy?" => "The grading policy is outlined in the syllabus for each course.",
        "How can I access the library?" => "Library access is available through the library portal.",
        "What are the rules for attendance?" => "Attendance rules can be found in the student handbook."
    ],
    'parent' => [
        "How can I view my child's grades?" => "You can view your child's grades through the parent portal.",
        "How do I communicate with teachers?" => "You can send messages to teachers via the parent portal.",
        "What are the school hours?" => "School hours are from 8 AM to 3 PM.",
        "How can I help my child with homework?" => "You can assist by providing a quiet study space and resources.",
        "What activities are available for my child?" => "Activities include sports, clubs, and after-school programs.",
        "How do I enroll my child?" => "Enrollment can be completed through the enrollment form on the website.",
        "What is the school calendar?" => "The school calendar is available on the school's website.",
        "How do I report a concern?" => "Concerns can be reported through the contact form on the website.",
        "What are the safety policies?" => "Safety policies are outlined in the student handbook.",
        "How can I volunteer at the school?" => "You can volunteer by contacting the school's volunteer coordinator."
    ],
    'teacher' => [
        "How do I create a lesson plan?" => "You can create lesson plans using the lesson planning tool.",
        "What are the assessment methods?" => "Assessment methods include tests, assignments, and projects.",
        "How can I contact parents?" => "You can contact parents through the messaging system.",
        "How do I update my course materials?" => "Course materials can be updated in the course management section.",
        "What resources are available for teachers?" => "Resources include lesson plans, instructional materials, and training.",
        "How do I manage my classroom?" => "You can manage your classroom by setting clear rules and expectations.",
        "What are the guidelines for grading?" => "Grading guidelines are outlined in the grading policy document.",
        "How do I access student information?" => "Student information can be accessed through the student management system.",
        "What professional development is available?" => "Professional development opportunities are listed on the faculty page.",
        "How can I collaborate with other teachers?" => "You can collaborate through team meetings and shared resources."
    ]
];
?>




