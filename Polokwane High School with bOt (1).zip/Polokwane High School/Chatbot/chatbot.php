<?php
header('Content-Type: application/json');

// Include responses
include('responses.php');

$data = json_decode(file_get_contents('php://input'), true);
$message = $data['message'] ?? '';
$role = $data['role'] ?? '';

$response = "I'm sorry, I didn't understand that.";

if (array_key_exists($role, $responses)) {
    foreach ($responses[$role] as $question => $answer) {
        if (strcasecmp(trim($message), $question) == 0) {
            $response = $answer;
            break;
        }
    }
}

echo json_encode(['response' => $response]);
?>
