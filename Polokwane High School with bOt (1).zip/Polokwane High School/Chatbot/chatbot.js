const roleQuestions = {
    admin: [
        "What is my role?",
        "How can I manage users?",
        "What reports can I generate?",
        "How do I reset a password?",
        "Where can I find help?",
        "What are the system requirements?",
        "How do I add new courses?",
        "How can I update user information?",
        "What is the fee structure?",
        "How can I contact support?"
    ],
    student: [
        "How do I enroll in a course?",
        "What is my course schedule?",
        "How do I submit assignments?",
        "Where can I find study materials?",
        "How can I contact my instructor?",
        "What are the exam dates?",
        "How do I check my grades?",
        "What is the grading policy?",
        "How can I access the library?",
        "What are the rules for attendance?"
    ],
    parent: [
        "How can I view my child's grades?",
        "How do I communicate with teachers?",
        "What are the school hours?",
        "How can I help my child with homework?",
        "What activities are available for my child?",
        "How do I enroll my child?",
        "What is the school calendar?",
        "How do I report a concern?",
        "What are the safety policies?",
        "How can I volunteer at the school?"
    ],
    teacher: [
        "How do I create a lesson plan?",
        "What are the assessment methods?",
        "How can I contact parents?",
        "How do I update my course materials?",
        "What resources are available for teachers?",
        "How do I manage my classroom?",
        "What are the guidelines for grading?",
        "How do I access student information?",
        "What professional development is available?",
        "How can I collaborate with other teachers?"
    ]
};

document.getElementById("role-button").addEventListener("click", () => {
    const role = prompt("Please enter your role: admin, student, parent, teacher").toLowerCase();
    if (roleQuestions[role]) {
        displayChoices(role);
    } else {
        displayMessage("Invalid role. Please select from admin, student, parent, or teacher.");
    }
});

function displayChoices(role) {
    const messageBox = document.getElementById("message-box");
    messageBox.innerHTML = `<div>You selected: ${role}. Here are the top 10 questions:</div>`;
    
    roleQuestions[role].forEach(question => {
        const button = document.createElement("button");
        button.innerText = question;
        button.onclick = () => fetchResponse(question, role);
        messageBox.appendChild(button);
    });
}

document.getElementById("send-button").addEventListener("click", () => {
    const userInput = document.getElementById("user-input").value;
    displayMessage(userInput);
    fetchResponse(userInput);  // Send user's input to fetch response.
    document.getElementById("user-input").value = "";  // Clear input
});

function displayMessage(message) {
    const messageBox = document.getElementById("message-box");
    messageBox.innerHTML += `<div class="user-message">${message}</div>`;
}

function fetchResponse(userInput, role) {
    const data = { message: userInput, role: role };

    fetch('chatbot.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        displayMessage(data.response);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
