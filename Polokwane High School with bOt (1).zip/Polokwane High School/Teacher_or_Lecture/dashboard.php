<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <style>
  
     
        .panel {
            border: 1px solid #ccc;
            padding: 20px;
            margin: 20px 0;
        }
        .panel h2 {
            margin-top: 0;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            background-color:  #495057;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to the Teacher Dashboard</h1>
        <div class="panel">
            <h2>Quick Actions</h2>

            <a href="teacher_results.php?page=results" >View Student Progress</a>

        </div>
        <div class="card">
            <a href="communication.php?page=communication">View Grades</a>
        </div>
    </div>

 
</body>
</html>
