<?php
include('../Database/database_connection.php');

$teacherID = $_SESSION['UserID'];

$studentResults = [];

$sql = "SELECT r.StudentID, r.Grade, r.Term, r.Subject, r.Mark, CONCAT(u.Name, ' ', u.Lastname) AS StudentName
        FROM results r
        JOIN users u ON r.StudentID = u.UserID
        JOIN teacher_assignments ta ON r.Subject COLLATE utf8mb4_unicode_ci = (SELECT s.SubjectName COLLATE utf8mb4_unicode_ci FROM subjects s WHERE s.SubjectID = ta.SubjectID)
        WHERE ta.TeacherID = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $teacherID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $studentResults[] = [
            'StudentName' => $row['StudentName'],
            'Grade' => $row['Grade'],
            'Term' => $row['Term'],
            'Subject' => $row['Subject'],
            'Mark' => $row['Mark']
        ];
    }
} else {
    echo "No results available for your subjects or stream.";
}

$stmt->close();
mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            width: 80%;
            margin: 0 auto;
        }
        canvas {
            height: 400px; 
            width: 100%;
        }
    </style>
</head>
<body>

<div class="chart-container">
    <h2>Student Marks Overview</h2>
    <canvas id="resultsChart"></canvas>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const studentResults = <?php echo json_encode($studentResults); ?>;

        const labels = studentResults.map(result => result.StudentName); 
        const marks = studentResults.map(result => result.Mark);

        const ctx = document.getElementById('resultsChart').getContext('2d');
        const resultsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Student Marks',
                    data: marks,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    fill: false 
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    tooltip: {
                        callbacks: {
                            title: function(tooltipItems) {
                                const item = tooltipItems[0].label;
                                return item; 
                            },
                            label: function(tooltipItem) {
                                const grade = studentResults[tooltipItem.dataIndex].Grade; 
                                const subject = studentResults[tooltipItem.dataIndex].Subject;
                                const mark = tooltipItem.raw;
                                return `Grade: ${grade}, Subject: ${subject}, Mark: ${mark}`; 
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 10, 
                            max: 100 
                        },
                        title: {
                            display: true,
                            text: 'Marks'
                        }
                    },
                    x: {
                        display: false
                    }
                }
            }
        });
    });
</script>

</body>
</html>
