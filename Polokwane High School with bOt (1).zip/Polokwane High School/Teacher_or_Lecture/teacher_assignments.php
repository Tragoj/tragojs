<?php 
include('../Database/database_connection.php'); 

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$teacherID = $_SESSION['UserID']; 

function fetchSubmittedAssignments($conn, $teacherID) {
    $query = "
    SELECT 
        s.StudentID, 
        s.FirstName, 
        s.LastName, 
        sub.FilePath AS SubmissionFilePath,
        sub.SubmissionDate,
        sub.GradingStatus,
        a.AssignmentID,
        a.SubjectID,
        su.SubjectName,
        r.Mark AS FinalMark,
        r.Term,
        s.Grade AS StudentGrade
    FROM submissions sub
    JOIN assignments a ON CAST(sub.AssignmentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = CAST(a.AssignmentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci
    JOIN students s ON CAST(s.StudentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = CAST(sub.StudentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci
    JOIN subjects su ON CAST(su.SubjectID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = CAST(a.SubjectID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci
    LEFT JOIN results r ON CAST(r.StudentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = CAST(s.StudentID AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci 
    AND CAST(r.Subject AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = CAST(su.SubjectName AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci 
    AND r.Term = ?
    ";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("SQL prepare failed: " . $conn->error);
    }

    $stmt->bind_param('i', $teacherID);
    $stmt->execute();
    return $stmt->get_result();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $term = $_POST['term']; 

    foreach ($_POST['assignment_mark'] as $studentID => $assignmentMark) {
        $examMark = $_POST['exam_mark'][$studentID] ?? null;
        $subjectID = $_POST['subject_id'][$studentID];

        $studentQuery = "SELECT FirstName, LastName, Grade FROM students WHERE StudentID = ?";
        $stmt = $conn->prepare($studentQuery);
        $stmt->bind_param('i', $studentID);
        $stmt->execute();
        $studentResult = $stmt->get_result()->fetch_assoc();
        
        $studentFirstName = $studentResult['FirstName'];
        $studentLastName = $studentResult['LastName'];
        $studentGrade = $studentResult['Grade'];

        $subjectQuery = "SELECT SubjectName FROM subjects WHERE SubjectID = ?";
        $stmt = $conn->prepare($subjectQuery);
        $stmt->bind_param('i', $subjectID);
        $stmt->execute();
        $result = $stmt->get_result();
        $subjectName = $result->fetch_assoc()['SubjectName'];

        if (empty($assignmentMark) && !empty($examMark)) {
            echo "Assignment mark must be entered before the exam mark for student $studentID.<br>";
            continue;
        }

        $finalMark = 0;
        if (!empty($assignmentMark)) {
            $assignmentPercentage = $assignmentMark * 0.40;
            $finalMark += $assignmentPercentage;
        }

        if (!empty($examMark)) {
            $examPercentage = $examMark * 0.60; 
            $finalMark += $examPercentage;
        }

        $checkResultQuery = "
            SELECT * FROM results 
            WHERE StudentID = ? 
            AND Subject = ? 
            AND Term = ?
        ";
        $stmt = $conn->prepare($checkResultQuery);
        $stmt->bind_param('iss', $studentID, $subjectName, $term);
        $stmt->execute();
        $existingResult = $stmt->get_result()->fetch_assoc();

        if ($existingResult) {
            $updateQuery = "
                UPDATE results 
                SET Mark = ?
                WHERE StudentID = ? 
                AND Subject = ? 
                AND Term = ?
            ";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param('diss', $finalMark, $studentID, $subjectName, $term);
        } else {
            $insertQuery = "
                INSERT INTO results (StudentID, Grade, Term, Subject, Mark)
                VALUES (?, ?, ?, ?, ?)
            ";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param('iissd', $studentID, $studentGrade, $term, $subjectName, $finalMark);
        }

        if ($stmt->execute()) {
            echo "Marks successfully saved for {$studentFirstName} {$studentLastName}<br>";
        } else {
            echo "Error saving marks for student $studentID: " . $stmt->error . "<br>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Submitted Assignments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }
        th {
            background-color: #e1f5fe;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h2>Submitted Assignments</h2>
    <form method="POST" action="">
        <label for="term">Select Term:</label>
        <select name="term" required>
            <option value="1">Term 1</option>
            <option value="2">Term 2</option>
            <option value="3">Term 3</option>
            <option value="4">Term 4</option>
        </select>
        <br><br>
        <table>
            <thead>
                <tr>
                <th>Student Name</th>
                    <th>Subject Name</th>
                    <th>Grade</th>
                    <th>Submission Date</th>
                    <th>Assignment File</th>
                    <th>Assignment Mark (out of 100)</th>
                    <th>Exam Mark (out of 100)</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $submittedAssignments = fetchSubmittedAssignments($conn, $teacherID);
            if ($submittedAssignments->num_rows > 0) {
                while ($row = $submittedAssignments->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row['FirstName'] . ' ' . $row['LastName']) . '</td>';
                    echo '<td>' . htmlspecialchars('Grade '.$row['StudentGrade']) . '</td>'; 
                    echo '<td>' . htmlspecialchars($row['SubjectName']) . '</td>'; 
            
                    echo '<td>' . htmlspecialchars($row['SubmissionDate']) . '</td>';
                    echo '<td><a href="' . htmlspecialchars($row['SubmissionFilePath']) . '" target="_blank">Download</a></td>';
                    echo '<td><input type="number" name="assignment_mark[' . $row['StudentID'] . ']" placeholder="Enter Assignment Mark" value="' . (!empty($row['FinalMark']) ? $row['FinalMark'] * (1 / 0.40) : '') . '"></td>';
                    echo '<td><input type="number" name="exam_mark[' . $row['StudentID'] . ']" placeholder="Enter Exam Mark"></td>';
                    echo '<input type="hidden" name="subject_id[' . $row['StudentID'] . ']" value="' . $row['SubjectID'] . '">';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="5">No assignments found.</td></tr>';
            }
            ?>
            </tbody>
        </table>
        <button type="submit">Submit Marks</button>
    </form>
</body>
</html>
