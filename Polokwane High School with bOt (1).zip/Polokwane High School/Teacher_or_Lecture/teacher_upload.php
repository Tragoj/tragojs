<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}


if (isset($_POST['upload'])) {
    $filename = $_FILES['resource']['name'];
    $tempname = $_FILES['resource']['tmp_name'];
    $folder = "resources/" . $filename;
    if (move_uploaded_file($tempname, $folder)) {
    
        $stmt = $conn->prepare("INSERT INTO resources (ResourceName, FilePath, UploadedBy, UploadedAt) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param('ssi', $filename, $folder, $_SESSION['UserID']);
        $stmt->execute();
        $stmt->close();
        echo "<script>alert('Resource uploaded successfully!');</script>";
    } else {
        echo "<script>alert('Failed to upload resource.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Resources</title>
    <link rel="stylesheet" href="styles.css"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .upload-container {
            width: 90%;
            max-width: 600px;
            margin: 30px auto;
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        input[type="file"] {
            width: 100%;
            margin-bottom: 10px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h2>Upload Resources</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="resource" required>
            <button type="submit" name="upload">Upload</button>
        </form>
    </div>
</body>
</html>
