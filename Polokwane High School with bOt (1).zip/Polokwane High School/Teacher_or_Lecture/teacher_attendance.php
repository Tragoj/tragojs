<?php  
include '../Database/database_connection.php';

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$message = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attendance_id'])) {
    $attendance_id = $_POST['attendance_id'];
    $latitude = floatval($_POST['latitude']);
    $longitude = floatval($_POST['longitude']);
    $user_id = $_SESSION['UserID'];

    // School location - Updated coordinates for Limpopo Connexions
    $school_lat = -23.9044900; // Updated latitude
    $school_long = 29.4688500; // Updated longitude
    $radius = 0.01; 

    function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371) {
        $latFrom = deg2rad($latitudeFrom);
        $lonFrom = deg2rad($longitudeFrom);
        $latTo = deg2rad($latitudeTo);
        $lonTo = deg2rad($longitudeTo);

        $latDelta = $latTo - $latFrom;
        $lonDelta = $lonTo - $lonFrom;

        $a = sin($latDelta / 2) * sin($latDelta / 2) +
             cos($latFrom) * cos($latTo) *
             sin($lonDelta / 2) * sin($lonDelta / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c; 
    }

    $distance = haversineGreatCircleDistance($latitude, $longitude, $school_lat, $school_long);

    if ($distance <= $radius) {
        $query = "SELECT ClassDate FROM attendance WHERE AttendanceID = ? AND TIMESTAMPDIFF(MINUTE, ClassDate, NOW()) <= 15";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $attendance_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $query = "INSERT INTO attendance_confirmation (RegisterID, StudentID, ConfirmedStatus, Latitude, Longitude) VALUES (?, ?, 'Yes', ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('iidd', $attendance_id, $user_id, $latitude, $longitude);

            if ($stmt->execute()) {
                $message = "<div class='success-message'>Attendance confirmed successfully!</div>";
            } else {
                $message = "<div class='error-message'>Error: " . htmlspecialchars($stmt->error) . "</div>";
            }
        } else {
            $message = "<div class='error-message'>Error: Attendance can no longer be confirmed. The register has expired.</div>";
        }
    } else {
        $message = "<div class='error-message'>You are too far from the school to confirm attendance.</div>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['class_date'])) {
    $class_date = $_POST['class_date'];

    $query = "INSERT INTO attendance (TeacherID, ClassDate, Status) VALUES (?, ?, 'Sent')";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('is', $_SESSION['UserID'], $class_date);
    if ($stmt->execute()) {
        $message = "<div class='success-message'>Attendance sent successfully!</div>";
    } else {
        $message = "<div class='error-message'>Error: " . htmlspecialchars($stmt->error) . "</div>";
    }
}

$schedule_query = "
    SELECT s.time, s.subject, s.day, s.grade 
    FROM schedule s 
    JOIN teacher_assignments ta ON s.subject = (SELECT SubjectName FROM subjects WHERE SubjectID = ta.SubjectID)
    WHERE ta.teacherID = ? 
    ORDER BY s.time";
$stmt = $conn->prepare($schedule_query);
$stmt->bind_param('i', $_SESSION['UserID']);
$stmt->execute();
$schedule_result = $stmt->get_result();

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Register</title>
    <style>
        .attendance-container h2 {
            text-align: center;
            color: #333;
        }

        .attendance-container form {
            display: flex;
            flex-direction: column;
        }

        .attendance-container input[type="datetime-local"],
        .attendance-container button {
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
        }

        .attendance-container button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .attendance-container button:hover {
            background-color: #218838;
        }

        .success-message, .error-message {
            text-align: center;
            padding: 10px;
            border-radius: 5px;
            display: block; 
        }
        .success-message {
            background-color: #28a745;
            color: white;
        }
        .error-message {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <?php if (!empty($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <div class="attendance-container">
        <h2>Attendance Register</h2>

        <form action="" method="post">
            <label for="classDate">Class Date:</label>
            <input type="datetime-local" id="classDate" name="class_date" required>
            <button type="submit">Send Attendance</button>
        </form>

        <h3>Your Scheduled Classes</h3>
        <ul>
            <?php if ($schedule_result->num_rows > 0): ?>
                <?php while ($row = $schedule_result->fetch_assoc()): ?>
                    <li>
                        <?php echo htmlspecialchars($row['subject']) . ' - ' . htmlspecialchars($row['day']) . ' at ' . htmlspecialchars(substr($row['time'], 0, 5)); ?>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li>No scheduled classes available.</li>
            <?php endif; ?>
        </ul>
    </div>

    <script>
        function showMessage() {
            const successMessage = document.querySelector('.success-message');
            const errorMessage = document.querySelector('.error-message');

            if (successMessage) {
                successMessage.style.display = 'block';
                setTimeout(() => { successMessage.style.display = 'none'; }, 5000);
            } 
            if (errorMessage) {
                errorMessage.style.display = 'block';
                setTimeout(() => { errorMessage.style.display = 'none'; }, 5000);
            }
        }

        window.onload = showMessage; 
    </script>
</body>
</html>

