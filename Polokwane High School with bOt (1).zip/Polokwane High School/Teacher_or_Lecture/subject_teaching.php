<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

function fetchTeacherAssignments($conn, $teacherID) {
    $query = "
        SELECT 
            a.AssignmentID,
            COALESCE(ss.SubjectName, s.SubjectName) AS SubjectName,
            a.Grade,
            COALESCE(st.StreamName, 'N/A') AS StreamName
        FROM 
            teacher_assignments a
        LEFT JOIN 
            subject_streams ss ON a.SubjectID = ss.SubjectID AND a.Grade IN ('10', '11', '12')
        LEFT JOIN 
            streams st ON ss.StreamID = st.StreamID AND a.Grade IN ('10', '11', '12')
        LEFT JOIN 
            subjects s ON a.SubjectID = s.SubjectID AND a.Grade NOT IN ('10', '11', '12')
        WHERE 
            a.TeacherID = ?
    ";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("SQL prepare failed: " . $conn->error);
    }
    $stmt->bind_param('i', $teacherID);
    $stmt->execute();
    return $stmt->get_result();
}

$teacherID = $_SESSION['UserID'];
$assignments = fetchTeacherAssignments($conn, $teacherID);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Assigned Subjects</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }
        th {
            background-color: #343a40;
            color:white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>My Assigned Subjects</h2>
        <table>
            <thead>
                <tr>
                    <th>Assignment ID</th>
                    <th>Subject Name</th>
                    <th>Grade</th>
                    <th>Stream Name</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($assignments->num_rows > 0) {
                    while ($row = $assignments->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['AssignmentID']}</td>
                                <td>{$row['SubjectName']}</td>
                                <td>{$row['Grade']}</td>
                                <td>{$row['StreamName']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No assignments found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
