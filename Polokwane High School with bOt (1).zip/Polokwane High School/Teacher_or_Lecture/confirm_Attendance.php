<?php
include('../Database/database_connection.php');
$teacher_id = $_SESSION['UserID'];


$sql = "SELECT s.FirstName, s.LastName, ac.ConfirmationID, ac.RegisterID 
        FROM attendance_confirmation ac 
        JOIN students s ON ac.StudentID = s.StudentID 
        WHERE ac.ConfirmedStatus IS NULL"; 

$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

echo "<style>
    * {
        box-sizing: border-box;
    }

    

    .attendance-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .attendance-table th,
    .attendance-table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }

    .attendance-table th {
        background-color: #f2f2f2;
        color: #333;
    }

    .attendance-table tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .attendance-table tr:hover {
        background-color: #f1f1f1;
    }


    input[type='submit'] {
        padding: 5px 10px;
        margin: 5px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    input[type='submit'][value='Present'] {
        background-color: #4CAF50;
        color: white;
    }

    input[type='submit'][value='Absent'] {
        background-color: #f44336;
        color: white;
    }

    input[type='submit']:hover {
        opacity: 0.8;
    }

  
    .h2 {
        color: #333;
        margin-bottom: 10px;
    }
</style>";

echo "<class='h2' h2>Confirm Attendance</class=h2>";
echo "<table class='attendance-table'>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Confirm</th>
        </tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['FirstName']}</td>
                <td>{$row['LastName']}</td>
                <td>
                    <form method='POST' action=''>
                        <input type='hidden' name='confirmation_id' value='{$row['ConfirmationID']}'>
                        <input type='submit' name='confirm' value='Present'>
                        <input type='submit' name='confirm' value='Absent'>
                    </form>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='3'>No attendance records found</td></tr>";
}
echo "</table>";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmation_id'])) {
    $confirmation_id = $_POST['confirmation_id'];
    $status = $_POST['confirm'] === 'Present' ? 'Present' : 'Absent';

    $update_sql = "UPDATE attendance_confirmation SET ConfirmedStatus = ? WHERE ConfirmationID = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $status, $confirmation_id);
    
    if ($update_stmt->execute()) {
        echo "<p>Attendance for confirmation ID {$confirmation_id} has been updated to {$status}.</p>";
    } else {
        echo "<p>Error updating attendance record: " . $update_stmt->error . "</p>";
    }

    $update_stmt->close();
}

$stmt->close();
?>
