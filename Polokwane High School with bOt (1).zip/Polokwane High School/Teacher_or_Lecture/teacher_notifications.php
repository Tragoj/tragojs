<?php
include '../Database/database_connection.php';

$userID = $_SESSION['UserID'];

function sendNotifications($conn, $userID) {
    $sqlEvents = "SELECT EventID, Title, StartDate FROM events WHERE StartDate > NOW()";
    $eventStmt = $conn->prepare($sqlEvents);
    $eventStmt->execute();
    $eventResult = $eventStmt->get_result();
    
    while ($event = $eventResult->fetch_assoc()) {
        $message = "New Event: '{$event['Title']}' is scheduled for '{$event['StartDate']}'.";
        insertNotification($conn, $userID, $message, 'Event');
    }

    $sqlMessages = "SELECT MessageID, Message, SentAt FROM chat_messages WHERE ReceiverID = ? AND SentAt > (NOW() - INTERVAL 1 DAY)";
    $messageStmt = $conn->prepare($sqlMessages);
    $messageStmt->bind_param("i", $userID);
    $messageStmt->execute();
    $messageResult = $messageStmt->get_result();
    
    while ($message = $messageResult->fetch_assoc()) {
        $messageContent = "New Message: '{$message['Message']}' received on '{$message['SentAt']}'.";
        insertNotification($conn, $userID, $messageContent, 'Message');
    }

    
    $sqlSchedules = "SELECT id, subject, day, time FROM schedule WHERE grade = ?"; 
    $scheduleStmt = $conn->prepare($sqlSchedules);
    $scheduleStmt->bind_param("i", $userID); 
    $scheduleStmt->execute();
    $scheduleResult = $scheduleStmt->get_result();
    
    while ($schedule = $scheduleResult->fetch_assoc()) {
        $scheduleMessage = "New Schedule: '{$schedule['subject']}' on '{$schedule['day']}' at '{$schedule['time']}'.";
        insertNotification($conn, $userID, $scheduleMessage, 'Schedule');
    }
}


function insertNotification($conn, $userID, $message, $type) {
    $insertSQL = "INSERT INTO notifications (UserID, Message, NotificationType, DateSent) VALUES (?, ?, ?, NOW())";
    $insertStmt = $conn->prepare($insertSQL);
    $insertStmt->bind_param("iss", $userID, $message, $type);
    $insertStmt->execute();
}


sendNotifications($conn, $userID);


$sqlNotifications = "SELECT NotificationID, Message, DateSent, IsRead FROM notifications WHERE UserID = ? ORDER BY DateSent DESC";
$stmt = $conn->prepare($sqlNotifications);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

echo "<div class='notifications'>";
while ($notification = $result->fetch_assoc()) {
    echo "<div class='notification'>";
    echo "<p>{$notification['Message']}</p>";
    echo "<small>Sent on: {$notification['DateSent']}</small>";
    if (!$notification['IsRead']) {
        echo "<button onclick='markAsRead({$notification['NotificationID']})'>Mark as Read</button>";
    }
    echo "</div>";
}
echo "</div>";

$stmt->close();
$conn->close();
?>

<script>
function markAsRead(notificationID) {
    fetch('mark_notification.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ notification_id: notificationID }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload(); 
        }
    });
}
</script>
