<?php
session_start();
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$teacher_id = $_SESSION['UserID'];

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_register'])) {
    $schedule_id = $_POST['schedule_id'];
    $register_date = $_POST['register_date'];

    $expiry_time = date('Y-m-d H:i:s', strtotime($register_date . ' + 30 minutes'));

    $query_insert = "INSERT INTO attendance_register (TeacherID, DateTimeSent, ExpiryTime, ScheduleID) VALUES (?, NOW(), ?, ?)";
    $stmt = $conn->prepare($query_insert);
    
    if ($stmt) {
        $stmt->bind_param('isi', $teacher_id, $expiry_time, $schedule_id);
        if ($stmt->execute()) {
            $message = "Attendance register sent successfully!";
        } else {
            $error = "Error sending the register: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error = "Error preparing the statement: " . $conn->error;
    }
}

$query = "
    SELECT sch.id AS ScheduleID, sch.day, sch.time, sch.grade, sub.SubjectName 
    FROM schedule sch
    JOIN subjects sub ON sch.subject = sub.SubjectID
    JOIN teacher_assignments ta ON ta.SubjectID = sch.subject AND ta.Grade = sch.grade
    WHERE ta.TeacherID='$teacher_id'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error fetching schedule: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Attendance Register</title>
    <style>
       
        .register-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .register-container h1 {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .register-container label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        .register-container select, 
        .register-container input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .register-container button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .register-container button:hover {
            background-color: #0056b3;
        }

        .message {
            color: green;
            font-weight: bold;
            text-align: center;
        }

        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h1>Send Attendance Register</h1>

        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php elseif ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="schedule">Select Schedule (Class/Period):</label>
            <select name="schedule_id" id="schedule" required>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    $schedule_info = $row['SubjectName'] . " - Grade " . $row['grade'] . " (" . $row['day'] . " " . $row['time'] . ")";
                    echo "<option value='" . $row['ScheduleID'] . "'>" . $schedule_info . "</option>";
                }
                ?>
            </select><br><br>

            <label for="register_date">Register Date:</label>
            <input type="date" id="register_date" name="register_date" value="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d'); ?>" required><br><br>

            <button type="submit" name="send_register">Send Register</button>
        </form>
    </div>
</body>
</html>
