<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$userID = $_SESSION['UserID'];
$schedule = [];

$teacher_query = "SELECT FirstName, LastName FROM teachers WHERE UserID = ?";
$stmt = mysqli_prepare($conn, $teacher_query);
if ($stmt === false) {
    die('MySQL prepare error: ' . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "i", $userID);
mysqli_stmt_execute($stmt);
$teacher_result = mysqli_stmt_get_result($stmt);
$teacher = mysqli_fetch_assoc($teacher_result);
mysqli_stmt_close($stmt);

if ($teacher === null) {
    die('Error: No teacher found with the given UserID.');
}

$schedule_query = "
    SELECT 
        s.time, 
        s.subject, 
        s.day,
        s.grade  -- Include the grade here
    FROM 
        schedule s 
    JOIN 
        teacher_assignments ta ON s.subject = (SELECT SubjectName FROM subjects WHERE SubjectID = ta.SubjectID)
   
    WHERE 
        ta.teacherID = ? 
    ORDER BY 
        s.time";
$stmt = mysqli_prepare($conn, $schedule_query);
if ($stmt === false) {
    die('MySQL prepare error: ' . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "i", $userID); 
mysqli_stmt_execute($stmt);
$schedule_result = mysqli_stmt_get_result($stmt);
$schedule = mysqli_fetch_all($schedule_result, MYSQLI_ASSOC);
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Schedule</title>
    <style>
        h1 {
            color: #333;
        }
        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .schedule-table th, .schedule-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .schedule-table th {
            background-color:  #343a40;
            color: white;
        }
        .error-message {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Schedule for <?php echo htmlspecialchars($teacher['FirstName'] . ' ' . $teacher['LastName']); ?></h1>
    <table class="schedule-table">
        <thead>
            <tr>
                <th>Time</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Grade</th>  
            </tr>
        </thead>
        <tbody>
            <?php if (count($schedule) > 0): ?>
                <?php foreach ($schedule as $entry): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(substr($entry['time'], 0, 5)); // Display time as HH:MM ?></td>
                        <td><?php echo htmlspecialchars($entry['subject']); ?></td>
                        <td><?php echo htmlspecialchars($entry['day']); ?></td>
                        <td><?php echo htmlspecialchars($entry['grade']); ?></td>  
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center;">No schedule available.</td> 
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
