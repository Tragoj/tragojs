<?php 
include('../Database/database_connection.php');
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'teacher') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$eventsSql = "SELECT * FROM events ORDER BY StartDate ASC";
$eventsStmt = $conn->prepare($eventsSql);

if ($eventsStmt->execute()) {
    $eventsResult = $eventsStmt->get_result();
    $events = [];
    
    while ($row = $eventsResult->fetch_assoc()) {
        $events[] = $row;
    }
} else {
    echo "Error executing events query: " . $eventsStmt->error;
}

$eventsStmt->close();
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <style>
    
        h1 {
            text-align: center;
            color: #333;
        }
        .event {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .event:last-child {
            border-bottom: none;
        }
        .event h3 {
            margin: 0;
            color: #007BFF;
        }
        .event p {
            margin: 5px 0;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            color: #777;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Upcoming Events</h1>

    <?php if (empty($events)): ?>
        <p>No upcoming events found.</p>
    <?php else: ?>
        <?php foreach ($events as $event): ?>
            <div class="event">
                <h3><?php echo htmlspecialchars($event['Title']); ?></h3>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($event['Description']); ?></p>
                <p><strong>Start Date:</strong> <?php echo date('Y-m-d H:i', strtotime($event['StartDate'])); ?></p>
                <p><strong>End Date:</strong> <?php echo date('Y-m-d H:i', strtotime($event['EndDate'])); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($event['Location']); ?></p>
                <p><strong>Created By:</strong> <?php echo htmlspecialchars($event['CreatedBy']); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <div class="footer">
        <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
    </div>
</div>

</body>
</html>
