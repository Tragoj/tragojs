<?php 
include('../Database/database_connection.php');

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $token = mysqli_real_escape_string($conn, $_POST['token']);

    $has_error = false;
    $query_params = [];

    if (empty($name)) { $query_params['name_error'] = true; $has_error = true; }
    if (empty($lastname)) { $query_params['lastname_error'] = true; $has_error = true; }
    if (empty($email)) { $query_params['email_error'] = true; $has_error = true; }
    if (empty($address)) { $query_params['address_error'] = true; $has_error = true; }
    if (empty($password)) { $query_params['password_error'] = true; $has_error = true; }
    if (empty($confirm_password)) { $query_params['confirm_password_error'] = true; $has_error = true; }
    if (empty($token)) { $query_params['token_error'] = true; $has_error = true; }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query_params['error'] = "Invalid email format.";
        $query_params['email_error'] = true;
        $has_error = true;
    }

    if ($password !== $confirm_password) {
        $query_params['error'] = "Passwords do not match.";
        $query_params['confirm_password_error'] = true;
        $has_error = true;
    }

    if ($has_error) {
        header("Location: signUp.php?" . http_build_query($query_params));
        exit();
    }

    $stmt = mysqli_prepare($conn, "SELECT * FROM pre_registration_tokens WHERE Token = ? AND is_used = FALSE");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) > 0) {
        $tokenData = mysqli_fetch_assoc($result);

        $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE Email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $emailResult = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($emailResult) > 0) {
            $error_message = "Email already taken.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "INSERT INTO users (Name, Lastname, Email, Address, Password, Role) 
                                           VALUES (?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "ssssss", $name, $lastname, $email, $address, $hashedPassword, $tokenData['Role']);

            if (mysqli_stmt_execute($stmt)) {
                $userId = mysqli_insert_id($conn);

                if ($tokenData['Role'] == 'teacher') {
                    $stmt_teacher = mysqli_prepare($conn, "INSERT INTO teachers (UserID, FirstName, LastName) VALUES (?, ?, ?)");
                    mysqli_stmt_bind_param($stmt_teacher, "iss", $userId, $name, $lastname);
                    if (!mysqli_stmt_execute($stmt_teacher)) {
                        $error_message = "Error registering teacher: " . mysqli_error($conn);
                    }
                } elseif ($tokenData['Role'] == 'parent') {
                    $stmt_parent = mysqli_prepare($conn, "INSERT INTO parents (UserID, FirstName, LastName) VALUES (?, ?, ?)");
                    mysqli_stmt_bind_param($stmt_parent, "iss", $userId, $name, $lastname);
                    if (!mysqli_stmt_execute($stmt_parent)) {
                        $error_message = "Error registering parent: " . mysqli_error($conn);
                    }
                } elseif ($tokenData['Role'] == 'student') {
                    $stmt_student = mysqli_prepare($conn, "INSERT INTO students (StudentID, FirstName, LastName, Grade) 
                                                           VALUES (?, ?, ?, ?)");
                    mysqli_stmt_bind_param($stmt_student, "isss", $userId, $name, $lastname, $tokenData['Grade']);
                    if (!mysqli_stmt_execute($stmt_student)) {
                        $error_message = "Error registering student: " . mysqli_error($conn);
                    }
                }

                if (empty($error_message)) {
                    $stmt = mysqli_prepare($conn, "UPDATE pre_registration_tokens 
                                                   SET is_used = 1, UsedByUserID = ?, UsedOn = CURRENT_TIMESTAMP 
                                                   WHERE Token = ?");
                    mysqli_stmt_bind_param($stmt, "is", $userId, $token);

                    if (mysqli_stmt_execute($stmt)) {
                        header("Location: login.php");
                        exit();
                    } else {
                        $error_message = "Error updating token status: " . mysqli_error($conn);
                    }
                }
            } else {
                $error_message = "Error registering user: " . mysqli_error($conn);
            }
        }
    } else {
        $error_message = "Invalid or used token.";
    }

    header("Location: signUp.php?error=" . urlencode($error_message));
    exit();
}
mysqli_close($conn);
?>
