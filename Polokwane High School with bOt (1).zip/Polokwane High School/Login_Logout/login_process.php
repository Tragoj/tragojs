<?php
session_start();
include('../Database/database_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $has_error = false;
    $query_params = [];

    if (empty($email)) {
        $query_params['email_error'] = true;
        $has_error = true;
    }

    if (empty($password)) {
        $query_params['password_error'] = true;
        $has_error = true;
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query_params['error'] = "Invalid email format.";
        $query_params['email_error'] = true;
        $has_error = true;
    }

    if ($has_error) {
        header("Location: login.php?" . http_build_query($query_params));
        exit();
    }

    $sql = "SELECT u.UserID, u.Password, u.Role, IFNULL(s.Grade, '') as Grade, ss.StreamID, u.active, u.DOB, u.gender, u.IDnumber
            FROM users u
            LEFT JOIN students s ON u.UserID = s.StudentID
            LEFT JOIN student_streams ss ON s.StudentID = ss.StudentID
            WHERE u.Email = ?";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $user_id, $hashed_password, $role, $grade, $stream_id, $active, $dob, $gender, $idnumber);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if (!$user_id) {
        $error_message = "User does not exist.";
    } elseif (!$active) {
        $error_message = "Account deactivated. Contact admin.";
    } elseif (!password_verify($password, $hashed_password)) {
        $error_message = "Wrong email or password.";
    } else {
        $_SESSION['UserID'] = $user_id;
        $_SESSION['role'] = $role;
        $_SESSION['grade'] = $grade;

        if (empty($dob) || empty($gender) || empty($idnumber)) {
            header("Location: ../Login_Logout/user_details_form.php");
            exit();
        }

        if ($role === 'student') {
            if ($grade == 8 || $grade == 9) {
                header("Location: ../student/student_dashboard.php");
                exit();
            } elseif ($grade >= 10 && $stream_id === null) { 
                header("Location: ../stream/stream_selection_page.php");
                exit();
            } elseif ($grade >= 10 && $stream_id !== null) {
                header("Location: ../student/student_dashboard.php");
                exit();
            }
        }

        switch ($role) {
            case 'parent':
                header("Location: ../Parent/parent_dashboard.php");
                exit();
            case 'teacher':
                header("Location: ../Teacher_or_Lecture/teacher_dashboard.php");
                exit();
            case 'admin':
                header("Location: ../Admin/admin_dashboard.php");
                exit();
            default:
                header("Location: default_dashboard.php");
                exit();
        }
    }

    $query_params['error'] = $error_message;
    header("Location: login.php?" . http_build_query($query_params));
    exit();
}

mysqli_close($conn);
?>
