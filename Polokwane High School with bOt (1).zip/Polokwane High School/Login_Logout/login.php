<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System - Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f9f9f7;
        }
        .container {
            width: 100%;
            max-width: 350px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            width: 100%;
            text-align: center;
            position: relative;
            left: 0;
            transition: left 0.5s ease-in-out;
        }
        .form-container.hidden {
            left: -100%; 
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        input {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .border_bottom_error {
            border-bottom: 2px solid red;
        }
        button {
            padding: 10px 20px;
            width: 100%;
            margin-top: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            color: white;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error-message {
            color: red;
            font-size: 14px;
           
            text-align: left;
            width: calc(100% - 20px);
           
        }
        .school-logo {
            width: 80px;
            margin-bottom: 20px;
        }
        .footer {
            margin-top: 20px;
            font-size: 12px;
            color: #777;
        }
        .footer a {
            color: #777;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div id="loginForm" class="form-container">
            <img src="" alt="School Logo" class="school-logo">
            <h2>Polokwane High School</h2>
            <div class="error-message">
                <?php
                if (isset($_GET['error'])) {
                    echo htmlspecialchars($_GET['error']);
                }
                ?>
            </div>
            <form id="login" method="post" action="login_process.php">
                <input type="email" name="email" placeholder="Email" 
                       class="<?php echo isset($_GET['email_error']) ? 'border_bottom_error' : ''; ?>">
                <?php if (isset($_GET['email_error'])) { echo '<div class="error-message">Required</div>'; } ?>
                <input type="password" name="password" placeholder="Password" 
                       class="<?php echo isset($_GET['password_error']) ? 'border_bottom_error' : ''; ?>">
                <?php if (isset($_GET['password_error'])) { echo '<div class="error-message">Required</div>'; } ?>
                <button type="submit">LogIn</button>
            </form>
            <button id="showRegister">SignUp</button>
            <div class="footer">
                &copy; <?php echo date("Y"); ?> Polokwane High School | <a href="#">Privacy Policy</a> | <a href="#">Contact Us</a>
            </div>
        </div>
    </div>

    <script>
        document.getElementById("showRegister").addEventListener("click", function() {
            document.getElementById("loginForm").classList.add("hidden");
            setTimeout(function() {
                window.location.href = "signup.php";
            }, 500);
        });
    </script>
</body>
</html>
