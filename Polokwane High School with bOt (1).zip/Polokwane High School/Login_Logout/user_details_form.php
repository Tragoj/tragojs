<?php
session_start();
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID'])) {
    header("Location: ../Login_Logout/logout.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $idNumber = $_POST['idnumber']; 
    $userID = $_SESSION['UserID'];
    $error_message = "";

    if (!preg_match('/^\d{13}$/', $idNumber)) {
        $error_message = "ID number must be exactly 13 digits.";
    } else {
        $dob_parts = explode("-", $dob);
        $year = substr($dob_parts[0], -2); 
        $month = str_pad($dob_parts[1], 2, "0", STR_PAD_LEFT); 
        $day = str_pad($dob_parts[2], 2, "0", STR_PAD_LEFT); 

        $expected_prefix = $year . $month . $day;

        if (substr($idNumber, 0, 6) !== $expected_prefix) {
            $error_message = "ID number does not match the date of birth.";
        }
    }

    if (empty($error_message)) {
        $sql = "SELECT COUNT(*) FROM users WHERE IDNumber = ? AND UserID != ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $idNumber, $userID);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $count);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);

        if ($count > 0) {
            $error_message = "ID number is already in use by another user.";
        }
    }

    if (empty($error_message)) {
        $sql = "UPDATE users SET Gender = ?, DOB = ?, IDNumber = ? WHERE UserID = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssi", $gender, $dob, $idNumber, $userID);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $role = $_SESSION['role']; 
        switch ($role) {
            case 'student':
                header("Location: ../student/student_dashboard.php");
                break;
            case 'parent':
                header("Location: ../parent/parent_dashboard.php");
                break;
            case 'teacher':
                header("Location: ../Teacher_or_Lecture/teacher_dashboard.php");
                break;
            default:
                header("Location: ../default_dashboard.php");
                break;
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details Form</title>
    <link rel="stylesheet" href="details.css">
</head>
<body>
    <h1>Fill Your Details</h1>
    <form action="" method="POST">
        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>
        <br>
        <label for="dob">Date of Birth:</label>
        <input type="date" name="dob" required>
        <br>
        <label for="idnumber">ID Number:</label>
        <input type="text" name="idnumber" required pattern="\d{13}" title="ID number must be exactly 13 digits.">
        <br>
        <?php if (isset($error_message) && !empty($error_message)): ?>
            <div style="color: red;"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
