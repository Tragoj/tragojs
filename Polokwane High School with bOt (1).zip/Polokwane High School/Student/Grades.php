<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$studentID = $_SESSION['UserID'];

$stmt = $conn->prepare("
  SELECT Subject, Mark, Term FROM results WHERE StudentID = ? 
");
$stmt->bind_param("i", $studentID); 
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Grades</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        h2 {
            margin-top: 0;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: relative; 
            bottom: 0;
            width: 100%;
        } 
    </style>
</head>
<body>
    <h2>Your Results:</h2>
    <?php
if ($result->num_rows > 0) {
    echo '<table>';
    echo '<thead><tr><th>Subject</th><th>Term</th><th>Mark</th></tr></thead>';
    echo '<tbody>';
    while ($row = $result->fetch_assoc()) {
        $mark = htmlspecialchars($row['Mark']); // Get the mark
        
        // Check the mark value and append ' PD' for distinction
        if ($mark >= 75) {
            $mark .= ' PD'; // Append ' PD' to the mark for distinction
        }
        
        echo '<tr><td>' . htmlspecialchars($row['Subject']) . '</td><td>' . htmlspecialchars($row['Term']) . '</td><td>' . $mark . '</td></tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p>No results found.</p>';
}
?>

<br>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p> 
    </footer>
</body>
</html>

<?php
$stmt->close();
$conn->close(); 
?>
