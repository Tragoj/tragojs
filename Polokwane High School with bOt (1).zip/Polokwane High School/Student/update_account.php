<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: Location: ../Login_Logout/logout.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userID = $_SESSION['UserID'];
    $old_password = $_POST['old_password'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    $has_error = false;
    $query_params = [];

    if (empty($old_password)) {
        $query_params['old_password_error'] = true;
        $has_error = true;
    }

    if (empty($name)) {
        $query_params['name_error'] = true;
        $has_error = true;
    }

    if (empty($email)) {
        $query_params['email_error'] = true;
        $has_error = true;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query_params['error'] = "Invalid email format.";
        $query_params['email_error'] = true;
        $has_error = true;
    }

    $query = "SELECT Password FROM users WHERE UserID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userID);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $current_hashed_password);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if (!password_verify($old_password, $current_hashed_password)) {
        $query_params['error'] = "Old password is incorrect.";
        $has_error = true;
    }

    if ($password && $password !== $confirm_password) {
        $query_params['error'] = "New passwords do not match!";
        $has_error = true;
    }

    if ($has_error) {
        header("Location: account_settings.php?" . http_build_query($query_params));
        exit();
    }

    $sql = "UPDATE users SET Name = ?, Email = ?" . ($password ? ", Password = ?" : "") . " WHERE UserID = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $hashed_password, $userID);
    } else {
        mysqli_stmt_bind_param($stmt, "ssi", $name, $email, $userID);
    }

    if (mysqli_stmt_execute($stmt)) {
        header("Location: account_settings.php?success=Account details updated successfully!");
    } else {
        header("Location: account_settings.php?error=Error updating account details: " . mysqli_error($conn));
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    exit();
}
?>
