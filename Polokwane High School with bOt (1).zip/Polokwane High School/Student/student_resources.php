<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$resources = $conn->query("SELECT * FROM resources ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Resources</title>
    <link rel="stylesheet" href="styles.css"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .resources-container {
            width: 90%;
            max-width: 800px;
            margin: 30px auto;
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .resource-item {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }
        .resource-item:last-child {
            border-bottom: none;
        }
        .resource-link {
            text-decoration: none;
            color: #007bff;
        }
        .resource-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="resources-container">
        <h2>Available Resources</h2>
        <?php while ($resource = $resources->fetch_assoc()): ?>
            <div class="resource-item">
                <a class="resource-link" href="<?php echo $resource['link']; ?>" download><?php echo $resource['title']; ?></a>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
