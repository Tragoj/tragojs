<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="../Admin/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        function confirmLogout(event) {
            event.preventDefault();
            var userConfirmed = confirm("Do you want to log out?");
            if (userConfirmed) {
                window.location.href = event.target.href;
            } else {
                return false;
            }
        }
    </script>
</head>
<body>
<script>
document.addEventListener('DOMContentLoaded', () => {
    let logoutTimer;
    let warningTimer;
    let countdownTimer;
    let countdownElement;

    function startTimers() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);

        if (countdownElement) {
            countdownElement.style.display = 'none'; 
        }

        warningTimer = setTimeout(showWarning, 60000); 
    }

    function showWarning() {
      
        if (!countdownElement) {
            countdownElement = document.createElement('div');
            countdownElement.id = 'countdown';
            countdownElement.style.position = 'fixed';
            countdownElement.style.top = '10px';
            countdownElement.style.right = '10px';
            countdownElement.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            countdownElement.style.color = '#fff';
            countdownElement.style.padding = '10px';
            countdownElement.style.borderRadius = '5px';
            countdownElement.style.zIndex = '1000';
            document.body.appendChild(countdownElement);
        }

        let countdown = 10;
        countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;
        countdownElement.style.display = 'block';


        countdownTimer = setInterval(() => {
            countdown--;
            countdownElement.textContent = `You will be logged out in ${countdown} seconds due to inactivity.`;

            if (countdown <= 0) {
                clearInterval(countdownTimer);
                logoutUser();
            }
        }, 1000);

    
        logoutTimer = setTimeout(logoutUser, 10000);
    }

    function logoutUser() {
        if (countdownElement) {
            countdownElement.style.display = 'none';
        }
        window.location.href = '../Login_Logout/logout.php'; 
    }

    function resetTimersOnActivity() {
        clearTimeout(logoutTimer);
        clearTimeout(warningTimer);
        clearInterval(countdownTimer);
        
        if (countdownElement) {
            countdownElement.style.display = 'none'; 
        }

        startTimers(); 
    }

 
    ['mousemove', 'keypress', 'click'].forEach(eventType => {
        document.addEventListener(eventType, resetTimersOnActivity);
    });

   
    startTimers();
});
</script>
<?php
include('../Database/database_connection.php');

session_start();

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: Location: ../Login_Logout/logout.php');
    exit();
}
$studentID = $_SESSION['UserID'];

$stmt = $conn->prepare("SELECT Name FROM users WHERE UserID = ?");
$stmt->bind_param("i", $studentID);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
$studentName = $student['Name'];
?>

<div class="container">
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Student Dashboard</h2>
        </div>
        <nav class="sidebar-nav">
            <ul>
                <li><a href="?page=home"><i class="fa-solid fa-home"></i> Home</a></li>
                <li><a href="?page=schedule"><i class="fa-solid fa-clipboard-list"></i> Schedule</a></li>
                <li><a href="?page=attendance"><i class="fa-solid fa-calendar"></i> Attendance</a></li>
                <li><a href="?page=grades"><i class="fa-solid fa-graduation-cap"></i> Grades</a></li>
                <li><a href="?page=assignments"><i class="fa-solid fa-book"></i> Subjects</a></li>
                <li><a href="?page=events"><i class="fa-solid fa-handshake"></i> Events</a></li>
                <li><a href="?page=messages"><i class="fa-solid fa-envelope"></i> Messages</a></li>
                <li><a href="?page=calendar"><i class="fa-solid fa-calendar-alt"></i> Calendar</a></li>
                <li><a href="?page=resources"><i class="fa-solid fa-folder"></i> Resources</a></li>
                <li><a href="?page=settings"><i class="fa-solid fa-cog"></i> Settings</a></li>
                <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fa-solid fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
    </aside>
    <main class="main-content">
        <header class="header">
            <h1>Welcome, <?php echo htmlspecialchars($studentName); ?></h1>
            <div class="header-actions">
                <li><a href="../Login_Logout/logout.php" onclick="return confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </div>
        </header>
        <section class="dashboard-content">
            <?php
            $page = isset($_GET['page']) ? $_GET['page'] : 'home';
            switch ($page) {
                case 'home':
                    include 'h.php';
                    break;
                case 'schedule':
                    include 'schedule.php';
                    break;
           
                case 'grades':
                    include 'Grades.php';
                    break;
                case 'assignments':
                    include 'index.php';
                    break;
                case 'messages':
                    include 'messages.php';
                    break;
                    case 'events':
                        include 'events.php';
                        break;
                case 'calendar':
                    include 'calendar.php';
                    break;
                case 'resources':
                    include 'student_resources.php';
                    break;
                case 'attendance':
                    include 'student_attendance.php';
                    break;
                case 'settings':
                    include 'settings.php';
                    break;
             
                default:
                    include 'home.php';
            }
            ?>
        </section>
    </main>
</div>
</body>
</html>
