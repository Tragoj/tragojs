<?php
include('../Database/database_connection.php');

session_start();
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID = $_SESSION['UserID'];
    $assignmentID = $_POST['assignment_id'];
    $file = $_FILES['assignment_file'];

    if ($file['type'] != 'application/pdf') {
        echo "Only PDF files are allowed.";
        exit();
    }

    $sql_check = "SELECT * FROM students WHERE StudentID = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("i", $studentID);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows === 0) {
        echo "Invalid StudentID.";
        exit();
    }

    $uploadDir = '../Admin/uploads/';
    $uploadFile = $uploadDir . basename($file['name']);

    if (move_uploaded_file($file['tmp_name'], $uploadFile)) {
        $sql = "INSERT INTO submissions (StudentID, AssignmentID, FilePath, SubmissionDate) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $studentID, $assignmentID, $uploadFile);
        $stmt->execute();

        echo "Assignment uploaded successfully.";
    } else {
        echo "Failed to upload assignment.";
    }
}

?>
