<?php
session_start();
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: Location: ../Login_Logout/logout.php');
    exit();
}

?>