<?php
include('../Database/database_connection.php');
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: Location: ../Login_Logout/logout.php');
    exit();
}

function generate_calendar($month, $year) {
    $daysOfWeek = array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
    $numDays = date('t', strtotime("$year-$month-01")); 
    $firstDay = date('w', strtotime("$year-$month-01")); 

    $calendar = '<table class="calendar">';
    $calendar .= '<thead>';
    $calendar .= '<tr>';
    foreach ($daysOfWeek as $day) {
        $calendar .= "<th>$day</th>";
    }
    $calendar .= '</tr>';
    $calendar .= '</thead>';
    $calendar .= '<tbody>';

    $calendar .= '<tr>';
    for ($i = 0; $i < $firstDay; $i++) {
        $calendar .= '<td class="empty"></td>';
    }

    for ($day = 1; $day <= $numDays; $day++) {
        if (($day + $firstDay - 1) % 7 == 0 && $day != 1) {
            $calendar .= '</tr><tr>'; 
        }
        $calendar .= "<td>$day</td>";
    }

    $totalDays = $numDays + $firstDay;
    while ($totalDays % 7 != 0) {
        $calendar .= '<td class="empty"></td>';
        $totalDays++;
    }

    $calendar .= '</tr>';
    $calendar .= '</tbody>';
    $calendar .= '</table>';

    return $calendar;
}

$month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

if ($month < 1) {
    $month = 12;
    $year--;
} elseif ($month > 12) {
    $month = 1;
    $year++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <style>
        h1 {
            text-align: center;
            color: #333;
        }
        .calendar {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .calendar thead {
            background-color: #007bff;
            color: #fff;
        }
        .calendar th, .calendar td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .calendar th {
            font-weight: bold;
        }
        .calendar td.empty {
            background-color: #f9f9f9;
        }
        .calendar td {
            background-color: #fff;
        }
        .calendar td:hover {
            background-color: #e9ecef;
            cursor: pointer;
        }
        .calendar-nav {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .calendar-nav a {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .calendar-nav a:hover {
            background-color: #0056b3;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: relative; /* Changed to relative for proper placement */
            bottom: 0;
            width: 100%;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="calendar-nav">
            <a href="?page=calendar&month=<?php echo $month - 1; ?>&year=<?php echo $year; ?>">Previous</a>
            <a href="?page=calendar&month=<?php echo $month + 1; ?>&year=<?php echo $year; ?>">Next</a>
        </div>
        <h1>Calendar for <?php echo date('F Y', strtotime("$year-$month-01")); ?></h1>
        <?php echo generate_calendar($month, $year); ?>
    </div>
    <footer>
    <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
</footer>
</body>
</html>
