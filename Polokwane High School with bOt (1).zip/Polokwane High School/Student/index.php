<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$student_id = $_SESSION['UserID'];

$grade_query = "SELECT Grade FROM students WHERE StudentID = ?";
$stmt = mysqli_prepare($conn, $grade_query);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $grade);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subjects and Assignments</title>
    <link rel="stylesheet" href="styles.css"> 
    <script>
        function showAssignments(subjectId) {
            document.getElementById('subject-list').style.display = 'none'; 
            document.getElementById('assignments').style.display = 'block';
            document.getElementById('assignment-loading').style.display = 'block'; 

           
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "subject_template.php?subject_id=" + subjectId, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.getElementById('assignments').innerHTML = xhr.responseText;
                    document.getElementById('assignment-loading').style.display = 'none';
                }
            };
            xhr.send();
        }
    </script>
 <style>
    .subject-list h1, .subject-list h2 {
    color: #333;
}

.subject-list ul {
    list-style-type: none;
    padding: 0;
}

.subject-list li {
    padding: 10px;
    background-color: #f4f4f4;
    margin-bottom: 5px;
    cursor: pointer;
}

.subject-list li:hover {
    background-color: #ddd;
}

form {
    margin-top: 10px;
}

button {
    padding: 5px 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}
footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px;
    position: relative; 
    bottom: 0;
    width: 100%;
} 

    </style>
</head>
<body>
    <header>
        <h1>Subjects</h1>
    </header>
    <main>
        <ul id="subject-list" class="subject-list">
            <?php if ($grade == 8 || $grade == 9): ?>
                <li><a href="javascript:void(0);" onclick="showAssignments(1)">Mathematics</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(2)">Creative Arts</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(3)">Technology</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(4)">Geography</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(5)">History</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(6)">Natural Sciences</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(7)">English First Additional Language</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(8)">Sepedi Home Language</a></li>
                <li><a href="javascript:void(0);" onclick="showAssignments(9)">Life Orientation</a></li>
            <?php else: ?>
                <?php
            
                $stream_query = "SELECT SubjectID, SubjectName FROM subject_streams WHERE StreamID IN (SELECT StreamID FROM student_streams WHERE StudentID = ?)";
                $stream_stmt = mysqli_prepare($conn, $stream_query);
                mysqli_stmt_bind_param($stream_stmt, "i", $student_id);
                mysqli_stmt_execute($stream_stmt);
                mysqli_stmt_bind_result($stream_stmt, $subject_id, $subject_name);
            
                while (mysqli_stmt_fetch($stream_stmt)) {
                    echo "<li><a href='javascript:void(0);' onclick='showAssignments(" . htmlspecialchars($subject_id) . ")'>" . htmlspecialchars($subject_name) . "</a></li>"; 
                }
                mysqli_stmt_close($stream_stmt);
            endif;
            ?>
        
        </ul>

        <div id="assignments" style="display: none;"></div>
        <div id="assignment-loading" style="display: none;">Loading assignments...</div>
    </main>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
    </footer>
</body>
</html>
