<?php  
include '../Database/database_connection.php';

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$message = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attendance_id'])) {
    $attendance_id = $_POST['attendance_id'];
    $latitude = floatval($_POST['latitude']);
    $longitude = floatval($_POST['longitude']);
    $user_id = $_SESSION['UserID'];

    // School location - Updated coordinates for Limpopo Connexions

    $school_lat = -33.9271; // Latitude of Limpopo Connexions
    $school_long = 18.42;   // Longitude of Limpopo Connexions
    $radius = 0.01; // Allowed radius in kilometers

    function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371) {
        $latFrom = deg2rad($latitudeFrom);
        $lonFrom = deg2rad($longitudeFrom);
        $latTo = deg2rad($latitudeTo);
        $lonTo = deg2rad($longitudeTo);

        $latDelta = $latTo - $latFrom;
        $lonDelta = $lonTo - $lonFrom;

        $a = sin($latDelta / 2) * sin($latDelta / 2) +
             cos($latFrom) * cos($latTo) *
             sin($lonDelta / 2) * sin($lonDelta / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c; 
    }

    $distance = haversineGreatCircleDistance($latitude, $longitude, $school_lat, $school_long);

    if ($distance <= $radius) {
        $query = "SELECT ClassDate FROM attendance WHERE AttendanceID = ? AND TIMESTAMPDIFF(MINUTE, ClassDate, NOW()) <= 15";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $attendance_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $query = "INSERT INTO attendance_confirmation (RegisterID, StudentID, ConfirmedStatus, Latitude, Longitude) VALUES (?, ?, 'Yes', ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('iidd', $attendance_id, $user_id, $latitude, $longitude);

            if ($stmt->execute()) {
                $message = "<div class='success-message'>Attendance confirmed successfully!</div>";
            } else {
                $message = "<div class='error-message'>Error: " . $stmt->error . "</div>";
            }
        } else {
            $message = "<div class='error-message'>Error: Attendance can no longer be confirmed. The register has expired.</div>";
        }
    } else {
        $message = "<div class='error-message'>You are too far from the school to confirm attendance.</div>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Register</title>
    <style>
        .attendance-container h2 {
            text-align: center;
            color: #333;
        }

        .attendance-container form {
            display: flex;
            flex-direction: column;
        }

        .attendance-container input[type="datetime-local"],
        .attendance-container button {
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
        }

        .attendance-container button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .attendance-container button:hover {
            background-color: #218838;
        }

        .success-message, .error-message {
            text-align: center;
            padding: 10px;
            border-radius: 5px;
            display: block; 
        }
        .success-message {
            background-color: #28a745;
            color: white;
        }
        .error-message {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="attendance-container">
        <h2>Attendance Register</h2>
        <?php if (!empty($message)): ?>
            <?php echo $message; ?>
        <?php endif; ?>

        <h3>Mark Your Attendance</h3>
        <ul>
            <?php
            $user_id = $_SESSION['UserID'];
            $query = "SELECT a.AttendanceID, a.ClassDate 
                      FROM attendance a 
                      LEFT JOIN attendance_confirmation ac ON a.AttendanceID = ac.RegisterID 
                      WHERE ac.StudentID IS NULL 
                      AND TIMESTAMPDIFF(MINUTE, a.ClassDate, NOW()) <= 15";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $student_attendance = $stmt->get_result();

            if ($student_attendance->num_rows > 0): 
                while ($row = $student_attendance->fetch_assoc()): ?>
                    <li>
                        Class Date: <?php echo $row['ClassDate']; ?>
                        <form method="post" action="" id="attendanceForm">
                            <input type="hidden" name="attendance_id" value="<?php echo $row['AttendanceID']; ?>">
                            <input type="hidden" name="latitude" id="latitude" value="">
                            <input type="hidden" name="longitude" id="longitude" value="">
                            <button type="submit" onclick="getLocation(event)">Mark Attendance</button>
                        </form>
                    </li>
                <?php endwhile; 
            else: ?>
                <li>No available registers to mark attendance. Please check back later.</li>
            <?php endif; ?>
        </ul>
    </div>

    <script>
        function getLocation(event) {
            event.preventDefault(); 
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    document.getElementById('latitude').value = position.coords.latitude;
                    document.getElementById('longitude').value = position.coords.longitude;
                    document.getElementById('attendanceForm').submit(); 
                }, function(error) {
                    alert("Geolocation failed: " + error.message);
                });
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        }
    </script>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
    </footer>
</body>
</html>
