<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$assignments = [];
$subject_name = '';
$submission_status = '';
$grading_status = '';
$time_remaining = '';
$last_modified = '';
$file_submissions = [];

if (isset($_GET['subject_id'])) {
    $subject_id = $_GET['subject_id'];
    $student_id = $_SESSION['UserID'];

    $sql = "SELECT students.Grade, student_streams.StreamID 
            FROM students 
            LEFT JOIN student_streams ON students.StudentID = student_streams.StudentID 
            WHERE students.StudentID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student_data = $result->fetch_assoc();
        $grade = $student_data['Grade'];
        $stream_id = $student_data['StreamID'];
    }

    $sql = "SELECT SubjectName FROM subjects WHERE SubjectID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $subject = $result->fetch_assoc();
        $subject_name = $subject['SubjectName'];
    }

    if ($grade == 8 || $grade == 9) {
        $sql = "SELECT assignments.AssignmentID, assignments.FilePath, assignments.DueDate, assignments.StartDate, assignments.status 
                FROM assignments 
                WHERE assignments.SubjectID = ? AND assignments.Grade = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $subject_id, $grade);
    } else {
        $sql = "SELECT assignments.AssignmentID, assignments.FilePath, assignments.DueDate, assignments.StartDate, assignments.status 
                FROM assignments 
                WHERE assignments.SubjectID = ? AND assignments.Grade = ? AND assignments.StreamID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $subject_id, $grade, $stream_id);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $assignments[] = $row;
        }
    }

    $sql = "SELECT submissions.FilePath, submissions.SubmissionDate, submissions.GradingStatus 
            FROM submissions 
            WHERE submissions.StudentID = ? AND submissions.AssignmentID IN (SELECT AssignmentID FROM assignments WHERE SubjectID = ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $student_id, $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $file_submissions[] = $row;
            $submission_status = 'Submitted for grading';
            $grading_status = $row['GradingStatus'];
            $last_modified = $row['SubmissionDate'];
        }
    } else {
        $submission_status = 'Not submitted';
        $grading_status = 'Not graded';
    }

    if (!empty($assignments)) {
        $due_date = new DateTime($assignments[0]['DueDate']);
        $now = new DateTime();
        $interval = $now->diff($due_date);
        $time_remaining = $interval->format('%a days %h hours %i minutes');
    }
}

$conn->close();
?>
