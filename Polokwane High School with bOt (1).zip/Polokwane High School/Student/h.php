<?php 
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$studentID = $_SESSION['UserID'];

$gradesSql = "SELECT Subject, Mark FROM results WHERE StudentID = ? ORDER BY Term DESC LIMIT 3";
$gradesStmt = $conn->prepare($gradesSql);
$gradesStmt->bind_param('i', $studentID);
$gradesStmt->execute();
$gradesResult = $gradesStmt->get_result();

$latestGrades = [];
while ($row = $gradesResult->fetch_assoc()) {
    $latestGrades[] = $row;
}

$attendanceSql = "SELECT ConfirmedStatus FROM attendance_confirmation WHERE StudentID = ?";
$attendanceStmt = $conn->prepare($attendanceSql);
$attendanceStmt->bind_param('i', $studentID);
$attendanceStmt->execute();
$attendanceResult = $attendanceStmt->get_result();

$attendanceData = $attendanceResult->fetch_assoc();

$attendanceStatus = $attendanceData ? $attendanceData['ConfirmedStatus'] : 'No records found'; // Default message



$gradesStmt->close();
$attendanceStmt->close();
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }


 
    
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: relative; /* Changed to relative for proper placement */
            bottom: 0;
            width: 100%;
        }

        .welcome-section, .summary-cards, .quick-links {
            margin: 20px 0;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
        }

        .summary-cards {
            display: flex; /* Use flexbox for card layout */
            justify-content: space-between; /* Space between cards */
        }

        .card {
            display: inline-block;
            width: 30%; /* Adjusted width for responsiveness */
            margin: 10px;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            text-align: center;
        }

        .card a {
            text-decoration: none;
            color: #333;
        }
    </style>
</head>
<body>

<section class="content">
    <section class="welcome-section">
        <p>Here's a quick overview of your current status and upcoming activities.</p>
    </section>

    <section class="summary-cards">
        <div class="card">
            <h3>Latest Grades</h3>
            <?php if (empty($latestGrades)): ?>
                <p>No grades available.</p>
            <?php else: ?>
                <?php foreach ($latestGrades as $grade): ?>
                    <p><?php echo htmlspecialchars($grade['Subject']) . ': ' . htmlspecialchars($grade['Mark']) . '%'; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="card">
            <h3>Attendance</h3>
            <p><?php echo htmlspecialchars($attendanceStatus); ?></p>
        </div>
        
    </section>

    <section class="quick-links">
        <h2>Quick Links</h2>
        <div class="card">
            <a href="student_dashboard.php?page=grades">View Grades</a>
        </div>
        <div class="card">
            <a href="student_dashboard.php?page=schedule">Check Timetable</a>
        </div>
        <div class="card">
            <a href="student_dashboard.php?page=messages">View Messages</a>
        </div>
        <div class="card">
        <a href="student_dashboard.php?page=events">View Upcoming Events</a>


    </section>

    <footer>
    <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
</footer>

</section>

</body>
</html>
