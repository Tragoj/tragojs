<?php
include('../Database/database_connection.php');

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'student') {
    header('Location: ../Login_Logout/logout.php');
    exit();
}

$userID = $_SESSION['UserID'];
$error_message = '';
$message = '';
$user_name = ''; 
$user_email = ''; 

$query = "SELECT Name, Email FROM users WHERE UserID = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $userID);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $user_name, $user_email);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = $_POST['old_password'];
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    $query = "SELECT Password FROM users WHERE UserID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $userID);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $hashed_password);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if (password_verify($old_password, $hashed_password)) {
        if (!empty($new_password) && $new_password !== $confirm_password) {
            $error_message = "New passwords do not match!";
        } else {
            $update_query = "UPDATE users SET Name = ?, Email = ? WHERE UserID = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ssi", $new_name, $new_email, $userID);
            mysqli_stmt_execute($update_stmt);
            mysqli_stmt_close($update_stmt);

            if (!empty($new_password)) {
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_password_query = "UPDATE users SET Password = ? WHERE UserID = ?";
                $password_stmt = mysqli_prepare($conn, $update_password_query);
                mysqli_stmt_bind_param($password_stmt, "si", $new_hashed_password, $userID);
                mysqli_stmt_execute($password_stmt);
                mysqli_stmt_close($password_stmt);
            }

            $update_student_query = "UPDATE students SET FirstName = ?, LastName = ? WHERE studentID = ?";
            $student_stmt = mysqli_prepare($conn, $update_student_query);
            mysqli_stmt_bind_param($student_stmt, "ssi", $new_name, $new_email, $userID);
            mysqli_stmt_execute($student_stmt);
            mysqli_stmt_close($student_stmt);

            $message = "successfully saved";
        }
    } else {
        $error_message = "Old password is incorrect!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings</title>
    <style>
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }  
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: #ff0000;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Account Settings</h1>
        <form id="settingsForm" action="" method="post">
            <div id="error-message" class="error">
                <?php if (!empty($error_message)): ?>
                    <p><?php echo htmlspecialchars($error_message); ?></p>
                <?php endif; ?>
                <?php if (!empty($message)): ?>
                    <p><?php echo htmlspecialchars($message); ?></p>
                <?php endif; ?>
            </div>
            <label for="old_password">Old Password:</label>
            <input type="password" id="old_password" name="old_password" placeholder="Enter your current password" required>
            
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user_name); ?>" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_email); ?>" required>
            
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter new password">
            
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password">
            
            <button type="submit">Save Changes</button>
            <button type="button" onclick="window.location.href='../Login_Logout/logout.php'">Back to Login</button>
        </form>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Polokwane High School</p>
    </footer>
</body>
</html>
